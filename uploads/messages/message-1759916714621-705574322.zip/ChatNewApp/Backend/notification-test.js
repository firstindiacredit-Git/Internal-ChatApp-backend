/**
 * Notification Test Console
 * यह script आपको console में notification status दिखाएगी
 */

require("dotenv").config();
const mongoose = require("mongoose");
const fcmService = require("./services/fcmService");

console.log("🚀 Notification Test Console शुरू हो रहा है...");
console.log("=".repeat(60));

// FCM Status Check
console.log("📱 FCM Service Status:");
console.log(
  `   Initialized: ${fcmService.isInitialized ? "✅ हाँ" : "❌ नहीं"}`
);

if (fcmService.isInitialized) {
  console.log("   Status: ✅ FCM Ready - Notifications भेजी जा सकती हैं!");
} else {
  console.log("   Status: ❌ FCM Not Ready - Simulation mode में है");
  console.log("   Mode: 🔧 Development/Testing mode");
}

console.log("");
console.log("🧪 Test Notification भेजते हैं...");

// Create a simple test without database
const testNotification = {
  title: "Test Notification 📱",
  body: "यह एक test message है - FCM working check",
  data: {
    type: "test",
    timestamp: Date.now().toString(),
    message: "Console test successful",
  },
};

// Simulate notification sending
console.log("📤 Notification Details:");
console.log(`   Title: ${testNotification.title}`);
console.log(`   Body: ${testNotification.body}`);
console.log(`   Data:`, JSON.stringify(testNotification.data, null, 4));

if (fcmService.isInitialized) {
  console.log("");
  console.log("✅ FCM Service Ready:");
  console.log("   - Real notifications भेजी जा सकती हैं");
  console.log("   - Android devices को push notifications मिलेंगी");
  console.log("   - Firebase project से connected है");
} else {
  console.log("");
  console.log("🔧 Simulation Mode Active:");
  console.log("   - Notifications console में log होंगी");
  console.log("   - Real push नहीं भेजी जाएंगी");
  console.log("   - Firebase credentials की जरूरत है");
}

console.log("");
console.log("📊 Current Configuration:");
console.log(`   Project ID: ${process.env.FIREBASE_PROJECT_ID || "Not set"}`);
console.log(
  `   Client Email: ${process.env.FIREBASE_CLIENT_EMAIL || "Not set"}`
);
console.log(
  `   Private Key: ${
    process.env.FIREBASE_PRIVATE_KEY ? "Set ✅" : "Not set ❌"
  }`
);

console.log("");
console.log("🔍 Service Account File Check:");
const fs = require("fs");
const path = require("path");
const serviceAccountPath = path.join(
  __dirname,
  "firebase-service-account.json"
);
const fileExists = fs.existsSync(serviceAccountPath);
console.log(`   File exists: ${fileExists ? "✅ हाँ" : "❌ नहीं"}`);

if (fileExists) {
  try {
    const serviceAccount = require("./firebase-service-account.json");
    console.log(`   Project ID: ${serviceAccount.project_id || "Missing"}`);
    console.log(`   Client Email: ${serviceAccount.client_email || "Missing"}`);
    console.log(
      `   Private Key: ${
        serviceAccount.private_key ? "Present ✅" : "Missing ❌"
      }`
    );
  } catch (error) {
    console.log(`   Error reading file: ${error.message}`);
  }
}

console.log("");
console.log("🎯 Next Steps:");
if (fcmService.isInitialized) {
  console.log("   1. ✅ FCM setup complete");
  console.log("   2. 📱 Get FCM token from Android app");
  console.log("   3. 🧪 Test with real device");
  console.log("   4. 🚀 Start main server");
} else {
  console.log("   1. 🔧 Fix Firebase credentials");
  console.log("   2. 📁 Check service account file");
  console.log("   3. 🔄 Restart server");
  console.log("   4. 🧪 Test again");
}

console.log("");
console.log("=".repeat(60));
console.log("📱 Notification Test Complete!");

// Exit after showing status
setTimeout(() => {
  process.exit(0);
}, 1000);
