/**
 * Restart Server Script
 * Restarts the server with FCM debugging enabled
 */

const { spawn } = require("child_process");
const path = require("path");

console.log("🔄 Restarting server with FCM debugging...");

// Set environment variables for better debugging
process.env.NODE_ENV = "development";
process.env.DEBUG = "firebase-admin:*";

// Start the server
const serverProcess = spawn("node", ["server.js"], {
  cwd: __dirname,
  stdio: "inherit",
  env: {
    ...process.env,
    NODE_ENV: "development",
    DEBUG: "firebase-admin:*",
  },
});

serverProcess.on("close", (code) => {
  console.log(`Server process exited with code ${code}`);
});

serverProcess.on("error", (error) => {
  console.error("Failed to start server:", error);
});

// Handle graceful shutdown
process.on("SIGINT", () => {
  console.log("\n🛑 Shutting down server...");
  serverProcess.kill("SIGINT");
  process.exit(0);
});

process.on("SIGTERM", () => {
  console.log("\n🛑 Shutting down server...");
  serverProcess.kill("SIGTERM");
  process.exit(0);
});

