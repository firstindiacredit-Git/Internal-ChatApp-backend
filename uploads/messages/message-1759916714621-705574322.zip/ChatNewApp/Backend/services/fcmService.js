/**
 * Firebase Cloud Messaging Service
 * Handles FCM notifications for Android app
 */

const admin = require("firebase-admin");
const User = require("../models/User");

class FCMService {
  constructor() {
    this.isInitialized = false;
    this.initializeFCM();
  }

  /**
   * Initialize Firebase Admin SDK
   */
  initializeFCM() {
    try {
      // Check if Firebase is already initialized
      if (admin.apps.length === 0) {
        let initialized = false;

        // Try to initialize with environment variables first
        if (
          process.env.FIREBASE_PRIVATE_KEY &&
          process.env.FIREBASE_PROJECT_ID &&
          process.env.FIREBASE_CLIENT_EMAIL
        ) {
          try {
            const serviceAccount = {
              type: "service_account",
              project_id: process.env.FIREBASE_PROJECT_ID,
              private_key_id: process.env.FIREBASE_PRIVATE_KEY_ID,
              private_key: process.env.FIREBASE_PRIVATE_KEY.replace(
                /\\n/g,
                "\n"
              ),
              client_email: process.env.FIREBASE_CLIENT_EMAIL,
              client_id: process.env.FIREBASE_CLIENT_ID,
              auth_uri: "https://accounts.google.com/o/oauth2/auth",
              token_uri: "https://oauth2.googleapis.com/token",
              auth_provider_x509_cert_url:
                "https://www.googleapis.com/oauth2/v1/certs",
              universe_domain: "googleapis.com",
            };

            admin.initializeApp({
              credential: admin.credential.cert(serviceAccount),
              projectId: process.env.FIREBASE_PROJECT_ID,
            });

            console.log(
              "📱 Firebase Admin SDK initialized with environment variables"
            );
            initialized = true;
          } catch (envError) {
            console.error(
              "📱 Error initializing with environment variables:",
              envError.message
            );
          }
        }

        // Try to initialize with service account file if env vars failed
        if (!initialized) {
          try {
            const path = require("path");
            const serviceAccountPath = path.join(
              __dirname,
              "../firebase-service-account.json"
            );

            // Check if service account file exists
            const fs = require("fs");
            if (fs.existsSync(serviceAccountPath)) {
              const serviceAccount = require(serviceAccountPath);

              // Validate required fields and check for placeholder values
              if (
                serviceAccount.project_id &&
                serviceAccount.private_key &&
                serviceAccount.client_email &&
                !serviceAccount.private_key.includes("YOUR_PRIVATE_KEY_HERE") &&
                !serviceAccount.private_key.includes("placeholder") &&
                serviceAccount.private_key_id !== "placeholder"
              ) {
                admin.initializeApp({
                  credential: admin.credential.cert(serviceAccount),
                  projectId: serviceAccount.project_id,
                });

                console.log(
                  "📱 Firebase Admin SDK initialized with service account file"
                );
                initialized = true;
              } else {
                console.error(
                  "📱 Service account file contains placeholder values - using development mode"
                );
              }
            } else {
              console.error(
                "📱 Service account file not found at:",
                serviceAccountPath
              );
            }
          } catch (fileError) {
            console.error(
              "📱 Error initializing with service account file:",
              fileError.message
            );
          }
        }

        // Fallback to development mode
        if (!initialized) {
          console.log(
            "📱 Firebase credentials not found - using development mode"
          );
          console.log(
            "📱 FCM notifications will be simulated via console logs"
          );
          console.log("📱 To enable FCM:");
          console.log(
            "   1. Set environment variables: FIREBASE_PROJECT_ID, FIREBASE_PRIVATE_KEY, FIREBASE_CLIENT_EMAIL"
          );
          console.log(
            "   2. Or place firebase-service-account.json in Backend/ directory"
          );
          this.isInitialized = false;
          return;
        }
      }

      this.isInitialized = true;
      console.log("📱 FCM Service initialized successfully");
    } catch (error) {
      console.error("📱 Error initializing FCM:", error);
      this.isInitialized = false;
    }
  }

  /**
   * Save FCM token for user
   */
  async saveFCMToken(userId, fcmToken, platform = "android") {
    try {
      const user = await User.findById(userId);
      if (!user) {
        throw new Error("User not found");
      }

      // Initialize fcmTokens array if it doesn't exist
      if (!user.fcmTokens) {
        user.fcmTokens = [];
      }

      // Check if token already exists
      const existingToken = user.fcmTokens.find(
        (token) => token.token === fcmToken
      );

      if (!existingToken) {
        user.fcmTokens.push({
          token: fcmToken,
          platform: platform,
          createdAt: new Date(),
        });
        await user.save();
        console.log(`📱 FCM token saved for user: ${user.name}`);
      }

      return true;
    } catch (error) {
      console.error("📱 Error saving FCM token:", error);
      return false;
    }
  }

  /**
   * Send FCM notification to user
   */
  async sendFCMNotification(userId, notificationData) {
    try {
      const user = await User.findById(userId).select("name fcmTokens");
      if (!user) {
        console.log(`📱 User not found: ${userId}`);
        return { success: false, message: "User not found" };
      }

      if (!this.isInitialized) {
        console.log(
          `📱 FCM not initialized - simulating notification for ${user.name}:`
        );
        console.log(`   Title: ${notificationData.title}`);
        console.log(`   Body: ${notificationData.body}`);
        console.log(`   Data:`, notificationData.data);
        return {
          success: true,
          message: "FCM not initialized - notification simulated",
          simulated: true,
        };
      }

      if (!user.fcmTokens || user.fcmTokens.length === 0) {
        console.log(`📱 No FCM tokens found for user: ${user.name}`);
        return { success: false, message: "No FCM tokens found" };
      }

      const message = {
        notification: {
          title: notificationData.title,
          body: notificationData.body,
          icon: notificationData.icon || "default",
        },
        data: {
          ...notificationData.data,
          click_action: "FLUTTER_NOTIFICATION_CLICK",
          timestamp: Date.now().toString(),
        },
        android: {
          notification: {
            icon: "ic_launcher",
            color: "#25D366",
            sound: "default",
            priority: "high",
            visibility: "public",
            channelId: "chat_notifications",
          },
          priority: "high",
          ttl: 3600000, // 1 hour TTL
        },
        apns: {
          payload: {
            aps: {
              alert: {
                title: notificationData.title,
                body: notificationData.body,
              },
              badge: 1,
              sound: "default",
            },
          },
        },
      };

      const results = [];

      // Send to all FCM tokens for this user
      for (const tokenData of user.fcmTokens) {
        try {
          const response = await admin.messaging().send({
            ...message,
            token: tokenData.token,
          });

          results.push({
            success: true,
            token: tokenData.token.substring(0, 20) + "...", // Hide full token in logs
            response,
            platform: tokenData.platform,
          });
          console.log(
            `📱 FCM notification sent to ${user.name} (${tokenData.platform}):`,
            response
          );
        } catch (error) {
          console.error(
            `📱 Failed to send FCM notification to ${user.name}:`,
            error.code || error.message
          );

          // Remove invalid tokens
          if (
            error.code === "messaging/registration-token-not-registered" ||
            error.code === "messaging/invalid-registration-token" ||
            error.code === "messaging/invalid-argument"
          ) {
            console.log(`📱 Removing invalid FCM token for ${user.name}`);
            await this.removeFCMToken(userId, tokenData.token);
          }

          results.push({
            success: false,
            token: tokenData.token.substring(0, 20) + "...",
            error: error.code || error.message,
            platform: tokenData.platform,
          });
        }
      }

      const successCount = results.filter((r) => r.success).length;
      const totalCount = results.length;

      console.log(
        `📱 FCM notification results: ${successCount}/${totalCount} successful`
      );

      return {
        success: successCount > 0,
        results,
        summary: {
          total: totalCount,
          successful: successCount,
          failed: totalCount - successCount,
        },
      };
    } catch (error) {
      console.error("📱 Error sending FCM notification:", error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Remove FCM token
   */
  async removeFCMToken(userId, fcmToken) {
    try {
      const user = await User.findById(userId);
      if (!user || !user.fcmTokens) {
        return false;
      }

      user.fcmTokens = user.fcmTokens.filter(
        (token) => token.token !== fcmToken
      );
      await user.save();

      console.log(`📱 FCM token removed for user: ${user.name}`);
      return true;
    } catch (error) {
      console.error("📱 Error removing FCM token:", error);
      return false;
    }
  }

  /**
   * Send message notification
   */
  async sendMessageNotification(
    receiverId,
    senderName,
    messageContent,
    chatId
  ) {
    const notificationData = {
      title: senderName,
      body:
        messageContent.length > 100
          ? messageContent.substring(0, 100) + "..."
          : messageContent,
      icon: "ic_launcher",
      data: {
        type: "message",
        chatId: chatId,
        senderName: senderName,
        timestamp: Date.now().toString(),
      },
    };

    return await this.sendFCMNotification(receiverId, notificationData);
  }

  /**
   * Send call notification
   */
  async sendCallNotification(
    receiverId,
    callerName,
    callType = "voice",
    callId
  ) {
    const notificationData = {
      title: `Incoming ${callType} call`,
      body: `${callerName} is calling you`,
      icon: "ic_launcher",
      data: {
        type: "call",
        callId: callId,
        callerName: callerName,
        callType: callType,
        timestamp: Date.now().toString(),
      },
    };

    return await this.sendFCMNotification(receiverId, notificationData);
  }

  /**
   * Send system notification
   */
  async sendSystemNotification(
    receiverId,
    title,
    message,
    type = "info",
    data = {}
  ) {
    const notificationData = {
      title: title,
      body: message,
      icon: "ic_launcher",
      data: {
        type: "system",
        category: type,
        message: message,
        timestamp: Date.now().toString(),
        ...data,
      },
    };

    return await this.sendFCMNotification(receiverId, notificationData);
  }

  /**
   * Handle notification click
   */
  handleNotificationClick(data) {
    console.log("📱 FCM notification clicked:", data);

    // Navigate based on notification type
    switch (data.type) {
      case "message":
        // Navigate to chat
        window.dispatchEvent(
          new CustomEvent("navigateToChat", {
            detail: { chatId: data.chatId },
          })
        );
        break;

      case "call":
        // Handle incoming call
        window.dispatchEvent(
          new CustomEvent("incomingCall", {
            detail: {
              callerName: data.callerName,
              callType: data.callType,
              callId: data.callId,
            },
          })
        );
        break;

      case "system":
        // Just open app for system notifications
        console.log("📱 System notification clicked");
        break;
    }
  }

  /**
   * Get authentication token
   */
  getAuthToken() {
    return (
      localStorage.getItem("token") ||
      localStorage.getItem("authToken") ||
      sessionStorage.getItem("token") ||
      sessionStorage.getItem("authToken")
    );
  }

  /**
   * Check if service is available
   */
  isAvailable() {
    return this.isNative && this.isAndroid;
  }
}

// Create singleton instance
const fcmService = new FCMService();

module.exports = fcmService;
