/**
 * Firebase Setup Script
 * This script helps configure Firebase for FCM notifications
 */

const fs = require("fs");
const path = require("path");

// Firebase configuration template
const firebaseConfig = {
  project_id: "extractor-9843e",
  private_key_id: "your_private_key_id_here",
  private_key:
    "-----BEGIN PRIVATE KEY-----\nYOUR_PRIVATE_KEY_HERE\n-----END PRIVATE KEY-----\n",
  client_email:
    "firebase-adminsdk-fbsvc@extractor-9843e.iam.gserviceaccount.com",
  client_id: "your_client_id_here",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url:
    "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40extractor-9843e.iam.gserviceaccount.com",
  universe_domain: "googleapis.com",
};

// Environment variables template
const envTemplate = `# Firebase Configuration for FCM
FIREBASE_PROJECT_ID=extractor-9843e
FIREBASE_PRIVATE_KEY_ID=your_private_key_id_here
FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\\nYOUR_PRIVATE_KEY_HERE\\n-----END PRIVATE KEY-----\\n"
FIREBASE_CLIENT_EMAIL=firebase-adminsdk-fbsvc@extractor-9843e.iam.gserviceaccount.com
FIREBASE_CLIENT_ID=your_client_id_here

# Database Configuration
MONGODB_URI=mongodb://localhost:27017/chatapp

# Server Configuration
PORT=8000
FRONTEND_URL=http://localhost:5173

# JWT Configuration
JWT_SECRET=your_jwt_secret_key_here_change_in_production

# Email Configuration (Optional)
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_email_password
EMAIL_SERVICE=gmail

# Cloudinary Configuration (Optional)
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
`;

console.log("🔥 Firebase Setup Instructions:");
console.log("");
console.log("1. Go to Firebase Console: https://console.firebase.google.com/");
console.log("2. Select your project: extractor-9843e");
console.log("3. Go to Project Settings > Service Accounts");
console.log('4. Click "Generate new private key"');
console.log("5. Download the JSON file");
console.log(
  "6. Replace the placeholder values in firebase-service-account.json with real values"
);
console.log("");
console.log("OR set environment variables:");
console.log("");
console.log("Create a .env file in the Backend directory with:");
console.log(envTemplate);
console.log("");
console.log("📱 To get your Firebase credentials:");
console.log("- Project ID: extractor-9843e");
console.log("- Go to Firebase Console > Project Settings > General");
console.log("- Copy the Project ID");
console.log("");
console.log("- Private Key: Generate from Service Accounts tab");
console.log(
  "- Client Email: Usually firebase-adminsdk-[random]@[project-id].iam.gserviceaccount.com"
);
console.log("");

// Write the service account file with template
const serviceAccountPath = path.join(
  __dirname,
  "firebase-service-account.json"
);
fs.writeFileSync(serviceAccountPath, JSON.stringify(firebaseConfig, null, 2));

console.log("✅ Template firebase-service-account.json created");
console.log(
  "⚠️  Please replace placeholder values with real Firebase credentials"
);

module.exports = { firebaseConfig, envTemplate };

