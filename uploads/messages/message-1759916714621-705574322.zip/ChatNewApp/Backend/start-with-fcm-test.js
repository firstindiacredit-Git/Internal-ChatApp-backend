/**
 * Start server with FCM testing
 * This script starts the server and provides FCM testing utilities
 */

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const fcmService = require("./services/fcmService");

const app = express();
const PORT = process.env.PORT || 8000;

// Middleware
app.use(cors());
app.use(express.json());

// Basic route
app.get("/", (req, res) => {
  res.json({
    message: "ChatApp Backend with FCM Testing",
    fcmInitialized: fcmService.isInitialized,
    timestamp: new Date().toISOString(),
  });
});

// FCM Status endpoint
app.get("/fcm-status", (req, res) => {
  res.json({
    success: true,
    data: {
      fcmInitialized: fcmService.isInitialized,
      projectId: process.env.FIREBASE_PROJECT_ID || "Not set",
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL || "Not set",
      hasPrivateKey: !!process.env.FIREBASE_PRIVATE_KEY,
      environment: process.env.NODE_ENV || "development",
    },
  });
});

// Test FCM endpoint
app.post("/test-fcm", async (req, res) => {
  try {
    const { userId, title, body, fcmToken } = req.body;

    if (!userId && !fcmToken) {
      return res.status(400).json({
        success: false,
        message: "Either userId or fcmToken is required",
      });
    }

    let result;

    if (fcmToken) {
      // Test with direct FCM token
      const User = require("./models/User");

      // Create temporary user for testing
      const tempUser = new User({
        name: "Test User",
        email: "test@example.com",
        fcmTokens: [
          {
            token: fcmToken,
            platform: "android",
            createdAt: new Date(),
          },
        ],
      });

      // Don't save to database, just use for testing
      result = await fcmService.sendFCMNotification(tempUser._id, {
        title: title || "Test Notification",
        body: body || "This is a test FCM notification",
        data: {
          type: "test",
          timestamp: Date.now().toString(),
        },
      });
    } else {
      // Test with existing user
      result = await fcmService.sendSystemNotification(
        userId,
        title || "Test Notification",
        body || "This is a test FCM notification",
        "test"
      );
    }

    res.json({
      success: true,
      message: "FCM test completed",
      data: result,
    });
  } catch (error) {
    console.error("FCM test error:", error);
    res.status(500).json({
      success: false,
      message: "FCM test failed",
      error: error.message,
    });
  }
});

// Start server
async function startServer() {
  try {
    // Connect to MongoDB
    await mongoose.connect(
      process.env.MONGODB_URI || "mongodb://localhost:27017/chatapp"
    );
    console.log("📱 Connected to MongoDB");

    // Start server
    app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`📱 FCM Service initialized: ${fcmService.isInitialized}`);

      if (!fcmService.isInitialized) {
        console.log("\n⚠️  FCM Service not initialized!");
        console.log("To fix this:");
        console.log("1. Set environment variables in .env file:");
        console.log("   FIREBASE_PROJECT_ID=extractor-9843e");
        console.log(
          "   FIREBASE_CLIENT_EMAIL=chatapp@horizontal-ally-425606-c4.iam.gserviceaccount.com"
        );
        console.log(
          '   FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\\n...\\n-----END PRIVATE KEY-----\\n"'
        );
        console.log("");
        console.log(
          "2. Or place firebase-service-account.json in Backend/ directory"
        );
        console.log("");
        console.log("3. Restart the server");
      } else {
        console.log("✅ FCM Service ready for push notifications!");
      }

      console.log("\n📋 Available endpoints:");
      console.log(`   GET  http://localhost:${PORT}/`);
      console.log(`   GET  http://localhost:${PORT}/fcm-status`);
      console.log(`   POST http://localhost:${PORT}/test-fcm`);
      console.log("\n📱 To test FCM:");
      console.log("   curl -X POST http://localhost:8000/test-fcm \\");
      console.log('     -H "Content-Type: application/json" \\');
      console.log(
        '     -d \'{"fcmToken":"YOUR_FCM_TOKEN","title":"Test","body":"Hello from server!"}\''
      );
    });
  } catch (error) {
    console.error("❌ Server startup error:", error);
    process.exit(1);
  }
}

// Handle graceful shutdown
process.on("SIGINT", async () => {
  console.log("\n📱 Shutting down server...");
  await mongoose.disconnect();
  console.log("📱 Database disconnected");
  process.exit(0);
});

startServer();
