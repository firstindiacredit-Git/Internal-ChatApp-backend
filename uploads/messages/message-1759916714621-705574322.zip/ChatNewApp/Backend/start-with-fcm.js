/**
 * Start server with FCM configuration
 */

// Set environment variables for FCM
process.env.FIREBASE_PROJECT_ID = "extractor-9843e";
process.env.FIREBASE_PRIVATE_KEY =
  "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC...\n-----END PRIVATE KEY-----\n";
process.env.FIREBASE_CLIENT_EMAIL =
  "firebase-adminsdk-fbsvc@extractor-9843e.iam.gserviceaccount.com";

console.log("🔥 Starting server with FCM configuration...");
console.log("📱 FCM Project ID:", process.env.FIREBASE_PROJECT_ID);
console.log("📱 FCM Client Email:", process.env.FIREBASE_CLIENT_EMAIL);

// Import and start the main server
require("./server.js");

