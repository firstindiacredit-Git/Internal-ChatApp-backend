/**
 * FCM Development Test Script
 * Tests FCM functionality in development mode (simulated notifications)
 */

const fcmService = require("./services/fcmService");
const mongoose = require("mongoose");
const User = require("./models/User");

async function testFCMDev() {
  try {
    console.log("🧪 Testing FCM Service in Development Mode...");

    // Connect to MongoDB
    const mongoURI =
      process.env.MONGODB_URI || "mongodb://localhost:27017/chatapp";
    await mongoose.connect(mongoURI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log("✅ Connected to MongoDB");

    // Find or create a test user
    let testUser = await User.findOne();
    if (!testUser) {
      console.log("📱 Creating test user...");
      testUser = new User({
        name: "Test User",
        email: "test@example.com",
        phone: "+1234567890",
        password: "test123",
        isVerified: true,
      });
      await testUser.save();
      console.log("✅ Test user created:", testUser.name);
    }

    console.log(`📱 Testing with user: ${testUser.name} (${testUser._id})`);

    // Test FCM status
    console.log("📱 FCM Initialized:", fcmService.isInitialized);

    // Test saving FCM token (will work even in dev mode)
    const testToken = "dev-test-token-" + Date.now();
    console.log("📱 Testing FCM token save...");
    const saveResult = await fcmService.saveFCMToken(
      testUser._id,
      testToken,
      "android"
    );
    console.log("📱 Token save result:", saveResult);

    // Test sending notification (will be simulated in dev mode)
    console.log("📱 Testing FCM notification (simulated)...");
    const notificationResult = await fcmService.sendMessageNotification(
      testUser._id,
      "Test Sender",
      "This is a test message from FCM in development mode!",
      "test-chat-id"
    );

    console.log(
      "📱 Notification result:",
      JSON.stringify(notificationResult, null, 2)
    );

    // Test different notification types
    console.log("📱 Testing call notification...");
    const callResult = await fcmService.sendCallNotification(
      testUser._id,
      "John Doe",
      "video",
      "call-123"
    );
    console.log("📱 Call notification result:", callResult.success);

    console.log("📱 Testing system notification...");
    const systemResult = await fcmService.sendSystemNotification(
      testUser._id,
      "System Update",
      "Your app has been updated!",
      "info"
    );
    console.log("📱 System notification result:", systemResult.success);

    // Clean up test token
    await fcmService.removeFCMToken(testUser._id, testToken);
    console.log("📱 Test token cleaned up");

    console.log("✅ FCM development test completed successfully!");
    console.log("");
    console.log(
      "📱 In development mode, notifications are simulated via console logs."
    );
    console.log("📱 To enable real FCM notifications:");
    console.log("   1. Get Firebase credentials from Firebase Console");
    console.log(
      "   2. Update firebase-service-account.json or set environment variables"
    );
    console.log("   3. Restart the server");
  } catch (error) {
    console.error("❌ FCM development test failed:", error);
  } finally {
    await mongoose.disconnect();
    console.log("📱 Disconnected from MongoDB");
  }
}

// Run the test
testFCMDev();

