/**
 * FCM Test Script
 * Tests Firebase Cloud Messaging setup and functionality
 */

require("dotenv").config();
const mongoose = require("mongoose");
const User = require("./models/User");
const fcmService = require("./services/fcmService");

// Test configuration
const TEST_CONFIG = {
  // Test user credentials (create a test user first)
  testEmail: "test@example.com",
  testUserName: "Test User",
  // Test FCM token (you'll need to get this from your Android app)
  testFCMToken: "YOUR_TEST_FCM_TOKEN_HERE",
  // MongoDB connection
  mongoUri: process.env.MONGODB_URI || "mongodb://localhost:27017/chatapp",
};

class FCMTester {
  constructor() {
    this.testUser = null;
  }

  /**
   * Initialize database connection
   */
  async initializeDatabase() {
    try {
      await mongoose.connect(TEST_CONFIG.mongoUri);
      console.log("📱 Connected to MongoDB");
      return true;
    } catch (error) {
      console.error("📱 MongoDB connection error:", error);
      return false;
    }
  }

  /**
   * Create or find test user
   */
  async setupTestUser() {
    try {
      // Try to find existing test user
      let user = await User.findOne({ email: TEST_CONFIG.testEmail });

      if (!user) {
        // Create test user
        user = new User({
          name: TEST_CONFIG.testUserName,
          email: TEST_CONFIG.testEmail,
          password: "testpassword123", // This should be hashed in real app
          isEmailVerified: true,
          fcmTokens: [],
        });
        await user.save();
        console.log("📱 Created test user:", user.name);
      } else {
        console.log("📱 Found existing test user:", user.name);
      }

      this.testUser = user;
      return user;
    } catch (error) {
      console.error("📱 Error setting up test user:", error);
      return null;
    }
  }

  /**
   * Test FCM service initialization
   */
  async testFCMInitialization() {
    console.log("\n📱 Testing FCM Service Initialization...");
    console.log("=".repeat(50));

    // Check if FCM service is initialized
    console.log("FCM Service initialized:", fcmService.isInitialized);

    if (!fcmService.isInitialized) {
      console.log(
        "❌ FCM Service not initialized - check your Firebase credentials"
      );
      console.log("Required environment variables:");
      console.log(
        "- FIREBASE_PROJECT_ID:",
        process.env.FIREBASE_PROJECT_ID ? "✅" : "❌"
      );
      console.log(
        "- FIREBASE_CLIENT_EMAIL:",
        process.env.FIREBASE_CLIENT_EMAIL ? "✅" : "❌"
      );
      console.log(
        "- FIREBASE_PRIVATE_KEY:",
        process.env.FIREBASE_PRIVATE_KEY ? "✅" : "❌"
      );

      console.log(
        "\nAlternatively, check if firebase-service-account.json exists"
      );
      const fs = require("fs");
      const path = require("path");
      const serviceAccountPath = path.join(
        __dirname,
        "firebase-service-account.json"
      );
      console.log(
        "Service account file exists:",
        fs.existsSync(serviceAccountPath) ? "✅" : "❌"
      );

      return false;
    }

    console.log("✅ FCM Service initialized successfully");
    return true;
  }

  /**
   * Test FCM token saving
   */
  async testFCMTokenSaving() {
    console.log("\n📱 Testing FCM Token Saving...");
    console.log("=".repeat(50));

    if (!this.testUser) {
      console.log("❌ No test user available");
      return false;
    }

    // Test with a dummy token first
    const dummyToken = "test_fcm_token_" + Date.now();
    const result = await fcmService.saveFCMToken(
      this.testUser._id,
      dummyToken,
      "android"
    );

    if (result) {
      console.log("✅ FCM token saving works");

      // Verify token was saved
      const updatedUser = await User.findById(this.testUser._id);
      const tokenExists = updatedUser.fcmTokens.some(
        (token) => token.token === dummyToken
      );
      console.log("✅ Token saved in database:", tokenExists);

      return true;
    } else {
      console.log("❌ FCM token saving failed");
      return false;
    }
  }

  /**
   * Test FCM notification sending (simulation mode)
   */
  async testFCMNotificationSending() {
    console.log("\n📱 Testing FCM Notification Sending...");
    console.log("=".repeat(50));

    if (!this.testUser) {
      console.log("❌ No test user available");
      return false;
    }

    const testNotification = {
      title: "Test Notification",
      body: "This is a test FCM notification from the backend",
      data: {
        type: "test",
        timestamp: Date.now().toString(),
      },
    };

    const result = await fcmService.sendFCMNotification(
      this.testUser._id,
      testNotification
    );

    if (result.success) {
      console.log("✅ FCM notification sending works");
      console.log("Result:", JSON.stringify(result, null, 2));
      return true;
    } else {
      console.log("❌ FCM notification sending failed");
      console.log("Error:", result.error || result.message);
      return false;
    }
  }

  /**
   * Test specific notification types
   */
  async testNotificationTypes() {
    console.log("\n📱 Testing Different Notification Types...");
    console.log("=".repeat(50));

    const tests = [
      {
        name: "Message Notification",
        test: () =>
          fcmService.sendMessageNotification(
            this.testUser._id,
            "Test Sender",
            "Hello! This is a test message.",
            "test_chat_id"
          ),
      },
      {
        name: "Call Notification",
        test: () =>
          fcmService.sendCallNotification(
            this.testUser._id,
            "Test Caller",
            "voice",
            "test_call_id"
          ),
      },
      {
        name: "System Notification",
        test: () =>
          fcmService.sendSystemNotification(
            this.testUser._id,
            "System Test",
            "This is a system notification test",
            "info"
          ),
      },
    ];

    for (const test of tests) {
      console.log(`\nTesting ${test.name}...`);
      try {
        const result = await test.test();
        if (result.success) {
          console.log(`✅ ${test.name} works`);
        } else {
          console.log(
            `❌ ${test.name} failed:`,
            result.error || result.message
          );
        }
      } catch (error) {
        console.log(`❌ ${test.name} error:`, error.message);
      }
    }
  }

  /**
   * Test with real FCM token (if provided)
   */
  async testWithRealToken() {
    console.log("\n📱 Testing with Real FCM Token...");
    console.log("=".repeat(50));

    if (TEST_CONFIG.testFCMToken === "YOUR_TEST_FCM_TOKEN_HERE") {
      console.log("❌ No real FCM token provided in TEST_CONFIG");
      console.log("To test with a real token:");
      console.log("1. Get FCM token from your Android app");
      console.log("2. Update testFCMToken in TEST_CONFIG");
      console.log("3. Run this test again");
      return false;
    }

    // Save real FCM token
    const saveResult = await fcmService.saveFCMToken(
      this.testUser._id,
      TEST_CONFIG.testFCMToken,
      "android"
    );

    if (!saveResult) {
      console.log("❌ Failed to save real FCM token");
      return false;
    }

    console.log("✅ Real FCM token saved");

    // Send test notification
    const testNotification = {
      title: "Real FCM Test",
      body: "This notification should appear on your Android device!",
      data: {
        type: "real_test",
        timestamp: Date.now().toString(),
      },
    };

    const sendResult = await fcmService.sendFCMNotification(
      this.testUser._id,
      testNotification
    );

    if (sendResult.success) {
      console.log("✅ Real FCM notification sent successfully!");
      console.log("📱 Check your Android device for the notification");
      return true;
    } else {
      console.log("❌ Failed to send real FCM notification");
      console.log("Error:", sendResult.error || sendResult.message);
      return false;
    }
  }

  /**
   * Run all tests
   */
  async runAllTests() {
    console.log("🚀 Starting FCM Test Suite");
    console.log("=".repeat(70));

    // Initialize
    const dbConnected = await this.initializeDatabase();
    if (!dbConnected) {
      console.log("❌ Cannot proceed without database connection");
      return;
    }

    const userSetup = await this.setupTestUser();
    if (!userSetup) {
      console.log("❌ Cannot proceed without test user");
      return;
    }

    // Run tests
    const tests = [
      () => this.testFCMInitialization(),
      () => this.testFCMTokenSaving(),
      () => this.testFCMNotificationSending(),
      () => this.testNotificationTypes(),
      () => this.testWithRealToken(),
    ];

    let passedTests = 0;
    let totalTests = tests.length;

    for (let i = 0; i < tests.length; i++) {
      try {
        const result = await tests[i]();
        if (result) passedTests++;
      } catch (error) {
        console.error(`❌ Test ${i + 1} crashed:`, error.message);
      }
    }

    // Summary
    console.log("\n📊 Test Summary");
    console.log("=".repeat(50));
    console.log(`Total Tests: ${totalTests}`);
    console.log(`Passed: ${passedTests}`);
    console.log(`Failed: ${totalTests - passedTests}`);
    console.log(
      `Success Rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`
    );

    if (passedTests === totalTests) {
      console.log(
        "\n🎉 All tests passed! Your FCM setup is working correctly."
      );
    } else {
      console.log(
        "\n⚠️  Some tests failed. Check the errors above and fix the issues."
      );
    }

    // Cleanup
    await mongoose.disconnect();
    console.log("\n📱 Database disconnected");
  }

  /**
   * Quick setup guide
   */
  static showSetupGuide() {
    console.log("\n📋 FCM Setup Guide");
    console.log("=".repeat(50));
    console.log("1. Get your Firebase service account key:");
    console.log(
      "   - Go to Firebase Console > Project Settings > Service Accounts"
    );
    console.log('   - Click "Generate new private key"');
    console.log(
      "   - Save as firebase-service-account.json in Backend/ directory"
    );
    console.log("");
    console.log("2. Or set environment variables:");
    console.log("   - FIREBASE_PROJECT_ID=extractor-9843e");
    console.log(
      "   - FIREBASE_CLIENT_EMAIL=chatapp@horizontal-ally-425606-c4.iam.gserviceaccount.com"
    );
    console.log("   - FIREBASE_PRIVATE_KEY=your_private_key_here");
    console.log("");
    console.log(
      "3. Get FCM token from your Android app and update TEST_CONFIG.testFCMToken"
    );
    console.log("");
    console.log("4. Run: node test-fcm-notifications.js");
  }
}

// Main execution
if (require.main === module) {
  const args = process.argv.slice(2);

  if (args.includes("--help") || args.includes("-h")) {
    FCMTester.showSetupGuide();
  } else {
    const tester = new FCMTester();
    tester.runAllTests().catch((error) => {
      console.error("❌ Test suite crashed:", error);
      process.exit(1);
    });
  }
}

module.exports = FCMTester;
