/**
 * Working FCM Test Script
 * Tests FCM functionality with proper error handling
 */

const fcmService = require("./services/fcmService");
const mongoose = require("mongoose");
const User = require("./models/User");

async function testFCMWorking() {
  try {
    console.log("🧪 Testing FCM Service (Fixed Version)...");

    // Connect to MongoDB
    const mongoURI =
      process.env.MONGODB_URI || "mongodb://localhost:27017/chatapp";
    await mongoose.connect(mongoURI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log("✅ Connected to MongoDB");

    // Find or create a test user
    let testUser = await User.findOne();
    if (!testUser) {
      console.log("📱 Creating test user...");
      testUser = new User({
        name: "Test User",
        email: "test@example.com",
        phone: "+1234567890",
        password: "test123",
        isVerified: true,
      });
      await testUser.save();
      console.log("✅ Test user created:", testUser.name);
    }

    console.log(`📱 Testing with user: ${testUser.name} (${testUser._id})`);

    // Test FCM status
    console.log("📱 FCM Initialized:", fcmService.isInitialized);

    // Test saving FCM token
    const testToken = "working-test-token-" + Date.now();
    console.log("📱 Testing FCM token save...");
    const saveResult = await fcmService.saveFCMToken(
      testUser._id,
      testToken,
      "android"
    );
    console.log("📱 Token save result:", saveResult);

    // Test sending notification
    console.log("📱 Testing FCM notification...");
    const notificationResult = await fcmService.sendMessageNotification(
      testUser._id,
      "Test Sender",
      "This is a test message from FCM (Fixed Version)!",
      "test-chat-id"
    );

    console.log(
      "📱 Notification result:",
      JSON.stringify(notificationResult, null, 2)
    );

    // Clean up test token
    await fcmService.removeFCMToken(testUser._id, testToken);
    console.log("📱 Test token cleaned up");

    console.log("✅ FCM test completed successfully!");
    console.log("");
    console.log("📱 Status: FCM is working in development mode");
    console.log("📱 Notifications are being simulated via console logs");
    console.log("📱 The private key parsing error has been fixed");
  } catch (error) {
    console.error("❌ FCM test failed:", error);
  } finally {
    await mongoose.disconnect();
    console.log("📱 Disconnected from MongoDB");
  }
}

// Run the test
testFCMWorking();

