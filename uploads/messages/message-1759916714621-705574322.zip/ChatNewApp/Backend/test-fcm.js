/**
 * FCM Test Script
 * Tests Firebase Cloud Messaging functionality
 */

const fcmService = require("./services/fcmService");
const mongoose = require("mongoose");
const User = require("./models/User");

// Test FCM functionality
async function testFCM() {
  try {
    console.log("🧪 Testing FCM Service...");

    // Check if FCM is initialized
    console.log("📱 FCM Initialized:", fcmService.isInitialized);

    if (!fcmService.isInitialized) {
      console.log(
        "❌ FCM not initialized. Please configure Firebase credentials first."
      );
      console.log("");
      console.log("To fix this:");
      console.log("1. Run: node setup-firebase.js");
      console.log("2. Get Firebase credentials from Firebase Console");
      console.log("3. Update firebase-service-account.json with real values");
      console.log("4. Or set environment variables");
      return;
    }

    // Connect to MongoDB
    const mongoURI =
      process.env.MONGODB_URI || "mongodb://localhost:27017/chatapp";
    await mongoose.connect(mongoURI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log("✅ Connected to MongoDB");

    // Find a test user
    const testUser = await User.findOne();
    if (!testUser) {
      console.log("❌ No users found in database. Please create a user first.");
      return;
    }

    console.log(`📱 Testing with user: ${testUser.name} (${testUser._id})`);

    // Test saving FCM token
    const testToken = "test-fcm-token-" + Date.now();
    console.log("📱 Testing FCM token save...");
    const saveResult = await fcmService.saveFCMToken(
      testUser._id,
      testToken,
      "android"
    );
    console.log("📱 Token save result:", saveResult);

    // Test sending notification
    console.log("📱 Testing FCM notification...");
    const notificationResult = await fcmService.sendMessageNotification(
      testUser._id,
      "Test Sender",
      "This is a test message from FCM!",
      "test-chat-id"
    );

    console.log(
      "📱 Notification result:",
      JSON.stringify(notificationResult, null, 2)
    );

    // Clean up test token
    await fcmService.removeFCMToken(testUser._id, testToken);
    console.log("📱 Test token cleaned up");

    console.log("✅ FCM test completed successfully!");
  } catch (error) {
    console.error("❌ FCM test failed:", error);
  } finally {
    await mongoose.disconnect();
    console.log("📱 Disconnected from MongoDB");
  }
}

// Run the test
testFCM();

