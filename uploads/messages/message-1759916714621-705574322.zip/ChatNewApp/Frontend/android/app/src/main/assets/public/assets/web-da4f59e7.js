import{W as n}from"./index-6adafdf4.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
