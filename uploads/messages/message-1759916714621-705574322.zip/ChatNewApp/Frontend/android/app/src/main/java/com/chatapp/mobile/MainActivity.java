package com.chatapp.mobile;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    // Capacitor will automatically register plugins
    // No manual registration needed
}
