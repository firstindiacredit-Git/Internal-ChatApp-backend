import React, { useState } from 'react';
import { useSocket } from '../contexts/SocketContext';
import { IoMdCall } from "react-icons/io";
import { MdMissedVideoCall } from "react-icons/md";
import { FaVideo, FaPhone } from "react-icons/fa";

const CallButton = ({ user, otherUser, callType = 'voice', onCallInitiated }) => {
  const { socket, isConnected } = useSocket();
  const [isCalling, setIsCalling] = useState(false);
  const [error, setError] = useState(null);

  const handleCall = async () => {
    if (!isConnected || !socket) {
      setError('Not connected to server');
      return;
    }

    if (!otherUser || !otherUser._id) {
      setError('Invalid user to call');
      return;
    }

    try {
      setIsCalling(true);
      setError(null);

      // Emit call initiation through socket
      socket.emit('call-initiate', {
        receiverId: otherUser._id,
        callType: callType,
      });

      // Don't call onCallInitiated here - wait for socket response

    } catch (error) {
      console.error('Error initiating call:', error);
      setError('Failed to initiate call');
      setIsCalling(false);
    }
  };

  const getCallIcon = () => {
    if (isCalling) {
      return callType === 'video' ? <FaVideo className="animate-pulse" /> : <FaPhone className="animate-pulse" />;
    }
    return callType === 'video' ? <FaVideo /> : <FaPhone />;
  };

  const getCallTitle = () => {
    if (isCalling) {
      return `Initiating ${callType} call...`;
    }
    return callType === 'video' ? 'Video Call' : 'Voice Call';
  };

  const getButtonClass = () => {
    let baseClass = 'flex items-center justify-center gap-2 px-4 py-2 rounded-lg transition-all duration-200 shadow-md hover:shadow-lg';
    
    if (isCalling) {
      baseClass += ' bg-gray-400 cursor-not-allowed';
    } else if (callType === 'video') {
      baseClass += ' bg-blue-500 hover:bg-blue-600 text-white';
    } else {
      baseClass += ' bg-green-500 hover:bg-green-600 text-white';
    }
    
    return baseClass;
  };

  return (
    <div className="call-button-container">
      {error && (
        <div className="absolute top-full left-0 mt-2 bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded-lg shadow-lg z-10">
          <div className="flex items-center justify-between gap-2">
            <span className="text-sm">{error}</span>
            <button 
              className="text-red-500 hover:text-red-700 text-lg font-bold"
              onClick={() => setError(null)}
            >
              ✕
            </button>
          </div>
        </div>
      )}
      
      <button
        className={getButtonClass()}
        onClick={handleCall}
        disabled={isCalling || !isConnected}
        title={getCallTitle()}
      >
        <span className="text-lg">{getCallIcon()}</span>
        <span className="text-sm font-medium">
          {isCalling ? 'Calling...' : (callType === 'video' ? 'Video' : 'Call')}
        </span>
      </button>
    </div>
  );
};

export default CallButton;
