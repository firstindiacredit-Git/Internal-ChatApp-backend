import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { API_CONFIG } from '../config/mobileConfig';
import Header from './Header';

const EditBio = ({ user, onUserUpdate }) => {
  const navigate = useNavigate();
  const [bio, setBio] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    // Set current bio when component mounts
    setBio(user.bio || '');
  }, [user.bio]);

  const handleSave = async () => {
    if (!bio.trim()) {
      setError('Please enter a bio');
      return;
    }

    if (bio.length > 500) {
      setError('Bio must be less than 500 characters');
      return;
    }

    try {
      setLoading(true);
      setError('');
      
      const response = await fetch(`${API_CONFIG.API_URL}/users/update-bio`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${user.token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          bio: bio.trim()
        })
      });

      const data = await response.json();

      if (data.success) {
        // Update user in localStorage
        const updatedUser = { ...user, bio: bio.trim() };
        localStorage.setItem('user', JSON.stringify(updatedUser));
        
        // Call parent callback to update user state
        if (onUserUpdate) {
          onUserUpdate(updatedUser);
        }
        
        // Navigate back to profile
        navigate('/chat');
      } else {
        setError(data.message || 'Failed to update bio');
      }
    } catch (err) {
      setError('Failed to update bio. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    navigate('/chat');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <Header 
        user={user}
        title="Edit Bio"
        showBackButton={true}
        onBackClick={handleBack}
        showActions={false}
      />

      <div className="pt-20 pb-8 px-4 max-w-md mx-auto">
        {/* Edit Bio Card */}
        <div className="bg-white rounded-3xl shadow-xl p-6 mb-6">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-whatsapp-green rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-white text-2xl">✏️</span>
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Edit Your Bio</h2>
            <p className="text-gray-600 text-sm">
              Tell others about yourself in a few words
            </p>
          </div>

          {/* Bio Input */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Bio
            </label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell us about yourself..."
              className="w-full min-h-[120px] p-4 border-2 border-gray-200 rounded-xl resize-none focus:border-whatsapp-green focus:outline-none transition-colors duration-200"
              maxLength={500}
            />
            <div className="flex justify-between items-center mt-2">
              <span className="text-xs text-gray-500">
                {bio.length}/500 characters
              </span>
              {bio.length > 450 && (
                <span className="text-xs text-orange-500">
                  {500 - bio.length} characters remaining
                </span>
              )}
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3">
            <button
              onClick={handleBack}
              className="flex-1 py-3 px-4 border-2 border-gray-200 text-gray-600 rounded-xl font-semibold hover:bg-gray-50 transition-colors duration-200"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={loading || !bio.trim()}
              className="flex-1 py-3 px-4 bg-whatsapp-green hover:bg-whatsapp-dark text-white rounded-xl font-semibold transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                  Saving...
                </>
              ) : (
                'Save Bio'
              )}
            </button>
          </div>
        </div>

        {/* Tips Card */}
        <div className="bg-blue-50 rounded-2xl p-4">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
              <span className="text-blue-600 text-sm">💡</span>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-blue-800 mb-1">Bio Tips</h3>
              <ul className="text-xs text-blue-600 space-y-1">
                <li>• Keep it short and interesting</li>
                <li>• Mention your interests or profession</li>
                <li>• Be authentic and friendly</li>
                <li>• You can always change it later</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditBio;
