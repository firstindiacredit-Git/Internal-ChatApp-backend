import React, { useState, useRef, useEffect } from 'react';
import { API_CONFIG } from '../config/mobileConfig';

const GroupDetails = ({ group, user, isVisible, onClose, onGroupUpdate }) => {
  const [groupData, setGroupData] = useState(group);
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [members, setMembers] = useState([]);
  const [loadingMembers, setLoadingMembers] = useState(false);
  const [showLeaveGroupModal, setShowLeaveGroupModal] = useState(false);
  const [longPressTimer, setLongPressTimer] = useState(null);
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [availableUsers, setAvailableUsers] = useState([]);
  const [selectedUsersToAdd, setSelectedUsersToAdd] = useState([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [showRemoveMemberModal, setShowRemoveMemberModal] = useState(false);
  const [memberToRemove, setMemberToRemove] = useState(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (isVisible && group) {
      setGroupData(group);
      fetchGroupMembers();
    }
  }, [isVisible, group]);

  const fetchGroupMembers = async () => {
    try {
      setLoadingMembers(true);
      const groupId = group._id || group.id;
      const response = await fetch(`${API_CONFIG.API_URL}/groups/${groupId}/members`, {
        headers: {
          'Authorization': `Bearer ${user.token}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        setMembers(data.data.members || []);
      }
    } catch (error) {
      console.error('Error fetching group members:', error);
    } finally {
      setLoadingMembers(false);
    }
  };

  const fetchAvailableUsers = async () => {
    try {
      setLoadingUsers(true);
      const response = await fetch(`${API_CONFIG.API_URL}/users`, {
        headers: {
          'Authorization': `Bearer ${user.token}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        // Filter out current members and current user
        const currentMemberIds = members.map(member => member._id);
        const availableUsers = data.data.users.filter(userData => 
          userData._id !== user.id && !currentMemberIds.includes(userData._id)
        );
        setAvailableUsers(availableUsers);
      }
    } catch (error) {
      console.error('Error fetching available users:', error);
    } finally {
      setLoadingUsers(false);
    }
  };

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setError('Please select an image file (JPG, PNG, GIF)');
        return;
      }
      
      const maxSize = 5 * 1024 * 1024;
      if (file.size > maxSize) {
        const fileSizeMB = (file.size / (1024 * 1024)).toFixed(1);
        setError(`File size too large! Your file is ${fileSizeMB}MB. Maximum 5MB allowed.`);
        return;
      }
      
      setSelectedFile(file);
      setError('');
      
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreviewUrl(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUploadAvatar = async () => {
    if (!selectedFile) return;
    
    setLoading(true);
    setError('');
    
    try {
      const formData = new FormData();
      formData.append('avatar', selectedFile);
      
      const groupId = group._id || group.id;
      const response = await fetch(`${API_CONFIG.API_URL}/groups/${groupId}/avatar`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${user.token}`,
        },
        body: formData,
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Avatar upload failed. Please try again.');
      }
      
      const updatedGroup = { ...groupData, avatar: data.data.avatar };
      setGroupData(updatedGroup);
      setSelectedFile(null);
      setPreviewUrl(null);
      
      if (onGroupUpdate) {
        onGroupUpdate(updatedGroup);
      }
      
      alert('✅ Group avatar updated successfully!');
      
    } catch (err) {
      console.error('Avatar upload error:', err);
      setError(err.message || 'Avatar upload failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveAvatar = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setError('');
  };

  const handleDeleteAvatar = async () => {
    if (!groupData.avatar) return;
    
    setLoading(true);
    setError('');
    
    try {
      const groupId = group._id || group.id;
      const response = await fetch(`${API_CONFIG.API_URL}/groups/${groupId}/avatar`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${user.token}`,
          'Content-Type': 'application/json',
        },
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Avatar delete failed. Please try again.');
      }
      
      const updatedGroup = { ...groupData, avatar: '' };
      setGroupData(updatedGroup);
      
      if (onGroupUpdate) {
        onGroupUpdate(updatedGroup);
      }
      
      alert('✅ Group avatar deleted successfully!');
      
    } catch (err) {
      console.error('Avatar delete error:', err);
      setError(err.message || 'Avatar delete failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const isCreator = groupData.creator && groupData.creator._id === user.id;

  // Long press handlers
  const handleLongPressStart = (e, member = null) => {
    e.preventDefault();
    const timer = setTimeout(() => {
      if (isCreator && member && member._id !== user.id) {
        // Creator can remove members
        setMemberToRemove(member);
        setShowRemoveMemberModal(true);
      } else if (!isCreator) {
        // Regular members can leave group
        setShowLeaveGroupModal(true);
      }
    }, 500); // 500ms long press
    setLongPressTimer(timer);
  };

  const handleLongPressEnd = () => {
    if (longPressTimer) {
      clearTimeout(longPressTimer);
      setLongPressTimer(null);
    }
  };

  const handleLeaveGroup = async () => {
    try {
      setLoading(true);
      const groupId = group._id || group.id;
      const response = await fetch(`${API_CONFIG.API_URL}/groups/${groupId}/leave`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${user.token}`,
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();

      if (data.success) {
        alert('✅ You have left the group successfully!');
        onClose(); // Close the group details modal
        // Notify parent component that user left the group
        if (onGroupUpdate) {
          onGroupUpdate(null);
        }
      } else {
        alert(data.message || 'Failed to leave group');
      }
    } catch (err) {
      console.error('Leave group error:', err);
      alert('Failed to leave group. Please try again.');
    } finally {
      setLoading(false);
      setShowLeaveGroupModal(false);
    }
  };

  const handleAddMembers = async () => {
    if (selectedUsersToAdd.length === 0) {
      alert('Please select at least one user to add');
      return;
    }

    try {
      setLoading(true);
      const groupId = group._id || group.id;
      const response = await fetch(`${API_CONFIG.API_URL}/groups/${groupId}/add-members`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${user.token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          memberIds: selectedUsersToAdd
        }),
      });

      const data = await response.json();

      if (data.success) {
        alert('✅ Members added successfully!');
        setSelectedUsersToAdd([]);
        setShowAddMemberModal(false);
        fetchGroupMembers(); // Refresh members list
        if (onGroupUpdate) {
          onGroupUpdate({ ...groupData, members: data.data.group.members });
        }
      } else {
        alert(data.message || 'Failed to add members');
      }
    } catch (err) {
      console.error('Add members error:', err);
      alert('Failed to add members. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveMember = async () => {
    if (!memberToRemove) return;

    try {
      setLoading(true);
      const groupId = group._id || group.id;
      const response = await fetch(`${API_CONFIG.API_URL}/groups/${groupId}/remove-member`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${user.token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          memberId: memberToRemove._id
        }),
      });

      const data = await response.json();

      if (data.success) {
        alert(`✅ ${memberToRemove.name} has been removed from the group!`);
        setShowRemoveMemberModal(false);
        setMemberToRemove(null);
        fetchGroupMembers(); // Refresh members list
        if (onGroupUpdate) {
          onGroupUpdate({ ...groupData, members: data.data.group.members });
        }
      } else {
        alert(data.message || 'Failed to remove member');
      }
    } catch (err) {
      console.error('Remove member error:', err);
      alert('Failed to remove member. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (!isVisible || !groupData) return null;

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: '#000000',
        zIndex: 2000,
        display: 'flex',
        flexDirection: 'column',
      }}
      onClick={onClose}
    >
      {/* WhatsApp-style Header */}
      <div
        style={{
          backgroundColor: '#075e54',
          color: 'white',
          padding: '16px 20px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderBottom: '1px solid #128c7e'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <button
            onClick={onClose}
            style={{
              background: 'none',
              border: 'none',
              color: 'white',
              fontSize: '20px',
              cursor: 'pointer',
              padding: '8px',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: '40px',
              height: '40px'
            }}
          >
            ←
          </button>
          <h2 style={{
            margin: 0,
            fontSize: '18px',
            fontWeight: '500'
          }}>
            Group info
          </h2>
        </div>
      </div>

      <div
        style={{
          backgroundColor: '#ffffff',
          flex: 1,
          overflowY: 'auto',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Group Header Section - WhatsApp Style */}
        <div style={{
          backgroundColor: '#ffffff',
          padding: '24px 20px',
          textAlign: 'center',
          borderBottom: '1px solid #e5e7eb'
        }}>
          {/* Group Avatar */}
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            marginBottom: '16px'
          }}>
            <div style={{ position: 'relative' }}>
              {previewUrl ? (
                <img 
                  src={previewUrl}
                  alt="Group Avatar Preview"
                  style={{
                    width: '120px',
                    height: '120px',
                    borderRadius: '50%',
                    objectFit: 'cover',
                    border: '3px solid #25D366',
                    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)'
                  }}
                />
              ) : groupData.avatar ? (
                <img 
                  src={groupData.avatar}
                  alt="Group Avatar"
                  style={{
                    width: '120px',
                    height: '120px',
                    borderRadius: '50%',
                    objectFit: 'cover',
                    border: '3px solid #25D366',
                    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)'
                  }}
                />
              ) : (
                <div 
                  style={{
                    width: '120px',
                    height: '120px',
                    borderRadius: '50%',
                    backgroundColor: '#25D366',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'white',
                    fontSize: '48px',
                    fontWeight: 'bold',
                    border: '3px solid #25D366',
                    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)'
                  }}
                >
                  {groupData.name?.charAt(0)?.toUpperCase() || 'G'}
                </div>
              )}
              
              {isCreator && (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  style={{
                    position: 'absolute',
                    bottom: '0',
                    right: '0',
                    width: '36px',
                    height: '36px',
                    backgroundColor: '#25D366',
                    border: '3px solid white',
                    borderRadius: '50%',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '18px',
                    color: 'white',
                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.2)'
                  }}
                  title="Change group photo"
                >
                  📷
                </button>
              )}
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              style={{ display: 'none' }}
            />
          </div>

          {/* Group Name */}
          <h3 style={{
            margin: '0 0 8px',
            fontSize: '24px',
            fontWeight: '600',
            color: '#374151'
          }}>
            {groupData.name}
          </h3>

          {/* Group Description */}
          {groupData.description && (
            <p style={{
              margin: '0 0 12px',
              fontSize: '16px',
              color: '#6b7280',
              lineHeight: '1.4'
            }}>
              {groupData.description}
            </p>
          )}

          {/* Member Count */}
          <p style={{
            margin: 0,
            fontSize: '14px',
            color: '#6b7280'
          }}>
            {members.length} participants
          </p>
        </div>

        {/* Avatar Upload Section */}
        {isCreator && selectedFile && (
          <div style={{
            backgroundColor: '#f8f9fa',
            padding: '16px 20px',
            borderBottom: '1px solid #e5e7eb'
          }}>
            <p style={{
              margin: '0 0 12px',
              fontSize: '14px',
              color: '#374151',
              fontWeight: '500'
            }}>
              📁 Selected: {selectedFile.name}
            </p>
            
            <div style={{
              display: 'flex',
              gap: '12px'
            }}>
              <button
                onClick={handleUploadAvatar}
                disabled={loading}
                style={{
                  flex: 1,
                  padding: '12px',
                  backgroundColor: '#25D366',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: loading ? 'not-allowed' : 'pointer',
                  opacity: loading ? 0.6 : 1
                }}
              >
                {loading ? 'Uploading...' : '📤 Upload'}
              </button>
              
              <button
                onClick={handleRemoveAvatar}
                disabled={loading}
                style={{
                  flex: 1,
                  padding: '12px',
                  backgroundColor: '#6b7280',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: loading ? 'not-allowed' : 'pointer',
                  opacity: loading ? 0.6 : 1
                }}
              >
                ❌ Cancel
              </button>
            </div>
          </div>
        )}

        {/* Delete Avatar Button */}
        {isCreator && groupData.avatar && !selectedFile && (
          <div style={{
            backgroundColor: '#ffffff',
            padding: '16px 20px',
            borderBottom: '1px solid #e5e7eb'
          }}>
            <button
              onClick={handleDeleteAvatar}
              disabled={loading}
              style={{
                width: '100%',
                padding: '12px',
                backgroundColor: '#ef4444',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                fontSize: '14px',
                fontWeight: '600',
                cursor: loading ? 'not-allowed' : 'pointer',
                opacity: loading ? 0.6 : 1
              }}
            >
              🗑️ Delete group photo
            </button>
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div style={{
            backgroundColor: '#fef2f2',
            border: '1px solid #fecaca',
            color: '#dc2626',
            padding: '12px 20px',
            fontSize: '14px',
            borderBottom: '1px solid #e5e7eb'
          }}>
            {error}
          </div>
        )}

        {/* Group Settings Section - WhatsApp Style */}
        <div style={{
          backgroundColor: '#ffffff',
          borderBottom: '1px solid #e5e7eb'
        }}>
          {/* Mute Notifications */}
          <div style={{
            padding: '16px 20px',
            borderBottom: '1px solid #f3f4f6',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            cursor: 'pointer'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <div style={{
                width: '24px',
                height: '24px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px'
              }}>
                🔕
              </div>
              <div>
                <div style={{
                  fontSize: '16px',
                  fontWeight: '500',
                  color: '#374151'
                }}>
                  Mute notifications
                </div>
                <div style={{
                  fontSize: '14px',
                  color: '#6b7280'
                }}>
                  Mute group notifications
                </div>
              </div>
            </div>
            <div style={{
              width: '20px',
              height: '20px',
              border: '2px solid #d1d5db',
              borderRadius: '4px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
            </div>
          </div>

          {/* Media, Links, and Docs */}
          <div style={{
            padding: '16px 20px',
            borderBottom: '1px solid #f3f4f6',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            cursor: 'pointer'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <div style={{
                width: '24px',
                height: '24px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px'
              }}>
                📎
              </div>
              <div>
                <div style={{
                  fontSize: '16px',
                  fontWeight: '500',
                  color: '#374151'
                }}>
                  Media, links, and docs
                </div>
                <div style={{
                  fontSize: '14px',
                  color: '#6b7280'
                }}>
                  View shared media and documents
                </div>
              </div>
            </div>
            <div style={{
              fontSize: '16px',
              color: '#6b7280'
            }}>
              →
            </div>
          </div>

          {/* Search */}
          <div style={{
            padding: '16px 20px',
            borderBottom: '1px solid #f3f4f6',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            cursor: 'pointer'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <div style={{
                width: '24px',
                height: '24px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px'
              }}>
                🔍
              </div>
              <div>
                <div style={{
                  fontSize: '16px',
                  fontWeight: '500',
                  color: '#374151'
                }}>
                  Search
                </div>
                <div style={{
                  fontSize: '14px',
                  color: '#6b7280'
                }}>
                  Search in group messages
                </div>
              </div>
            </div>
            <div style={{
              fontSize: '16px',
              color: '#6b7280'
            }}>
              →
            </div>
          </div>
        </div>

        {/* Group Members Section - WhatsApp Style */}
        <div style={{
          backgroundColor: '#ffffff'
        }}>
          <div style={{
            padding: '16px 20px 8px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}>
            <div style={{
              fontSize: '14px',
              fontWeight: '600',
              color: '#6b7280',
              textTransform: 'uppercase',
              letterSpacing: '0.5px'
            }}>
              {members.length} participants
            </div>
            
            {isCreator && (
              <button
                onClick={() => {
                  fetchAvailableUsers();
                  setShowAddMemberModal(true);
                }}
                style={{
                  backgroundColor: '#25D366',
                  color: 'white',
                  border: 'none',
                  borderRadius: '20px',
                  padding: '8px 16px',
                  fontSize: '12px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px'
                }}
              >
                + Add
              </button>
            )}
          </div>
          
          {loadingMembers ? (
            <div style={{
              padding: '20px',
              textAlign: 'center',
              color: '#6b7280'
            }}>
              Loading participants...
            </div>
          ) : (
            <div>
              {members.map((member, index) => (
                <div
                  key={member._id || index}
                  style={{
                    padding: '12px 20px',
                    borderBottom: index < members.length - 1 ? '1px solid #f3f4f6' : 'none',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '16px',
                    cursor: 'pointer',
                    userSelect: 'none'
                  }}
                  onMouseDown={(e) => handleLongPressStart(e, member)}
                  onMouseUp={handleLongPressEnd}
                  onMouseLeave={handleLongPressEnd}
                  onTouchStart={(e) => handleLongPressStart(e, member)}
                  onTouchEnd={handleLongPressEnd}
                  title={isCreator && member._id !== user.id ? "Hold to remove member" : !isCreator ? "Hold to leave group" : ""}
                >
                  {member.avatar ? (
                    <img 
                      src={member.avatar} 
                      alt={member.name}
                      style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '50%',
                        objectFit: 'cover'
                      }}
                    />
                  ) : (
                    <div style={{
                      width: '48px',
                      height: '48px',
                      borderRadius: '50%',
                      backgroundColor: '#25D366',
                      color: 'white',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '18px',
                      fontWeight: 'bold'
                    }}>
                      {member.name?.charAt(0)?.toUpperCase() || 'U'}
                    </div>
                  )}
                  
                  <div style={{ flex: 1 }}>
                    <div style={{
                      fontSize: '16px',
                      fontWeight: '500',
                      color: '#374151',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px'
                    }}>
                      {member.name}
                      {member._id === groupData.creator?._id && (
                        <span style={{
                          backgroundColor: '#25D366',
                          color: 'white',
                          fontSize: '10px',
                          padding: '2px 6px',
                          borderRadius: '10px',
                          fontWeight: '600'
                        }}>
                          admin
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Bottom Spacing */}
        <div style={{ height: '20px' }}></div>
      </div>

      {/* Leave Group Modal */}
      {showLeaveGroupModal && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            zIndex: 3000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '20px'
          }}
          onClick={() => setShowLeaveGroupModal(false)}
        >
          <div
            style={{
              backgroundColor: 'white',
              borderRadius: '12px',
              padding: '24px',
              maxWidth: '320px',
              width: '100%',
              textAlign: 'center',
              boxShadow: '0 10px 30px rgba(0, 0, 0, 0.3)'
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{
              fontSize: '48px',
              marginBottom: '16px'
            }}>
              🚪
            </div>
            
            <h3 style={{
              margin: '0 0 8px',
              fontSize: '20px',
              fontWeight: '600',
              color: '#374151'
            }}>
              Leave Group
            </h3>
            
            <p style={{
              margin: '0 0 24px',
              fontSize: '14px',
              color: '#6b7280',
              lineHeight: '1.5'
            }}>
              Are you sure you want to leave "{groupData.name}"? You won't receive messages from this group anymore.
            </p>
            
            <div style={{
              display: 'flex',
              gap: '12px'
            }}>
              <button
                onClick={() => setShowLeaveGroupModal(false)}
                disabled={loading}
                style={{
                  flex: 1,
                  padding: '12px',
                  backgroundColor: '#f3f4f6',
                  color: '#374151',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: loading ? 'not-allowed' : 'pointer',
                  opacity: loading ? 0.6 : 1
                }}
              >
                Cancel
              </button>
              
              <button
                onClick={handleLeaveGroup}
                disabled={loading}
                style={{
                  flex: 1,
                  padding: '12px',
                  backgroundColor: '#ef4444',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: loading ? 'not-allowed' : 'pointer',
                  opacity: loading ? 0.6 : 1
                }}
              >
                {loading ? 'Leaving...' : 'Leave Group'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Member Modal */}
      {showAddMemberModal && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            zIndex: 3000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '20px'
          }}
          onClick={() => setShowAddMemberModal(false)}
        >
          <div
            style={{
              backgroundColor: 'white',
              borderRadius: '12px',
              padding: '24px',
              maxWidth: '400px',
              width: '100%',
              maxHeight: '80vh',
              overflowY: 'auto',
              boxShadow: '0 10px 30px rgba(0, 0, 0, 0.3)'
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '20px'
            }}>
              <h3 style={{
                margin: 0,
                fontSize: '20px',
                fontWeight: '600',
                color: '#374151'
              }}>
                Add Members
              </h3>
              <button
                onClick={() => setShowAddMemberModal(false)}
                style={{
                  background: 'none',
                  border: 'none',
                  fontSize: '24px',
                  cursor: 'pointer',
                  color: '#6b7280'
                }}
              >
                ×
              </button>
            </div>

            {loadingUsers ? (
              <div style={{ textAlign: 'center', padding: '20px' }}>
                Loading users...
              </div>
            ) : (
              <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
                {availableUsers.map((userData) => (
                  <div
                    key={userData._id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      padding: '12px',
                      borderBottom: '1px solid #f3f4f6',
                      cursor: 'pointer'
                    }}
                    onClick={() => {
                      if (selectedUsersToAdd.includes(userData._id)) {
                        setSelectedUsersToAdd(prev => prev.filter(id => id !== userData._id));
                      } else {
                        setSelectedUsersToAdd(prev => [...prev, userData._id]);
                      }
                    }}
                  >
                    {userData.avatar ? (
                      <img
                        src={userData.avatar}
                        alt={userData.name}
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '50%',
                          objectFit: 'cover',
                          marginRight: '12px'
                        }}
                      />
                    ) : (
                      <div
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: '50%',
                          backgroundColor: '#25D366',
                          color: 'white',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '16px',
                          fontWeight: 'bold',
                          marginRight: '12px'
                        }}
                      >
                        {userData.name?.charAt(0)?.toUpperCase() || 'U'}
                      </div>
                    )}
                    
                    <div style={{ flex: 1 }}>
                      <div style={{
                        fontSize: '16px',
                        fontWeight: '500',
                        color: '#374151'
                      }}>
                        {userData.name}
                      </div>
                    </div>
                    
                    <div style={{
                      width: '20px',
                      height: '20px',
                      border: '2px solid #d1d5db',
                      borderRadius: '4px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      backgroundColor: selectedUsersToAdd.includes(userData._id) ? '#25D366' : 'transparent'
                    }}>
                      {selectedUsersToAdd.includes(userData._id) && (
                        <span style={{ color: 'white', fontSize: '12px' }}>✓</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div style={{
              display: 'flex',
              gap: '12px',
              marginTop: '20px'
            }}>
              <button
                onClick={() => setShowAddMemberModal(false)}
                disabled={loading}
                style={{
                  flex: 1,
                  padding: '12px',
                  backgroundColor: '#f3f4f6',
                  color: '#374151',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: loading ? 'not-allowed' : 'pointer',
                  opacity: loading ? 0.6 : 1
                }}
              >
                Cancel
              </button>
              
              <button
                onClick={handleAddMembers}
                disabled={loading || selectedUsersToAdd.length === 0}
                style={{
                  flex: 1,
                  padding: '12px',
                  backgroundColor: '#25D366',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: loading || selectedUsersToAdd.length === 0 ? 'not-allowed' : 'pointer',
                  opacity: loading || selectedUsersToAdd.length === 0 ? 0.6 : 1
                }}
              >
                {loading ? 'Adding...' : `Add ${selectedUsersToAdd.length} Member${selectedUsersToAdd.length !== 1 ? 's' : ''}`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Remove Member Modal */}
      {showRemoveMemberModal && memberToRemove && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            zIndex: 3000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '20px'
          }}
          onClick={() => setShowRemoveMemberModal(false)}
        >
          <div
            style={{
              backgroundColor: 'white',
              borderRadius: '12px',
              padding: '24px',
              maxWidth: '320px',
              width: '100%',
              textAlign: 'center',
              boxShadow: '0 10px 30px rgba(0, 0, 0, 0.3)'
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{
              fontSize: '48px',
              marginBottom: '16px'
            }}>
              🚫
            </div>
            
            <h3 style={{
              margin: '0 0 8px',
              fontSize: '20px',
              fontWeight: '600',
              color: '#374151'
            }}>
              Remove Member
            </h3>
            
            <p style={{
              margin: '0 0 24px',
              fontSize: '14px',
              color: '#6b7280',
              lineHeight: '1.5'
            }}>
              Are you sure you want to remove <strong>{memberToRemove.name}</strong> from "{groupData.name}"?
            </p>
            
            <div style={{
              display: 'flex',
              gap: '12px'
            }}>
              <button
                onClick={() => setShowRemoveMemberModal(false)}
                disabled={loading}
                style={{
                  flex: 1,
                  padding: '12px',
                  backgroundColor: '#f3f4f6',
                  color: '#374151',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: loading ? 'not-allowed' : 'pointer',
                  opacity: loading ? 0.6 : 1
                }}
              >
                Cancel
              </button>
              
              <button
                onClick={handleRemoveMember}
                disabled={loading}
                style={{
                  flex: 1,
                  padding: '12px',
                  backgroundColor: '#ef4444',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: loading ? 'not-allowed' : 'pointer',
                  opacity: loading ? 0.6 : 1
                }}
              >
                {loading ? 'Removing...' : 'Remove'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GroupDetails;
