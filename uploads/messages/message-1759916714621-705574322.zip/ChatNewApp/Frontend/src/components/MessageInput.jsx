import React, { useState, useRef, useEffect } from 'react';
import { useSocket } from '../contexts/SocketContext'
import { API_CONFIG } from '../config/mobileConfig';
import '../styles/WhatsAppStory.css';

const MessageInput = ({ receiverId, onMessageSent, disabled = false, currentUserId, isGroupChat = false, userToken, isBlocked = false, blockedUserName = '' }) => {
  const [message, setMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [typingTimeout, setTypingTimeout] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const textareaRef = useRef(null);
  const fileInputRef = useRef(null);
  const { sendMessage, startTyping, stopTyping } = useSocket();

  const handleSendMessage = async () => {
    if ((!message.trim() && !selectedFile) || !receiverId || disabled || isBlocked) return;
    
    // Show alert if trying to send to blocked user
    if (isBlocked) {
      alert(`Messaging is not available with ${blockedUserName}.`);
      return;
    }

    const messageToSend = message.trim();
    let attachment = null;
    
    try {
      // If there's a file to upload, upload it first
      if (selectedFile) {
        console.log('📎 File selected for upload:', selectedFile.name, selectedFile.type, selectedFile.size);
        setIsUploading(true);
        
        try {
          attachment = await uploadFile(selectedFile);
          console.log('✅ File uploaded successfully:', attachment);
          
          // Send message with attachment via socket
          console.log('📤 Sending message with attachment via socket:', { 
            receiverId, 
            messageToSend, 
            attachment,
            messageType: attachment.type,
            isGroupChat 
          });
          sendMessage(receiverId, messageToSend, attachment.type, isGroupChat, attachment);
        } catch (uploadError) {
          console.error('❌ File upload failed:', uploadError);
          setIsUploading(false);
          throw new Error(`File upload failed: ${uploadError.message}`);
        }
      } else {
        // Send text message via socket
        console.log('📤 Sending text message via socket:', { receiverId, messageToSend, isGroupChat });
        console.log('📤 Socket context:', { sendMessage: typeof sendMessage, isConnected: true });
        sendMessage(receiverId, messageToSend, 'text', isGroupChat);
      }
      
      // Create temporary message for immediate UI update
      const tempMessage = {
        _id: `temp-${Date.now()}`,
        content: messageToSend,
        sender: { _id: currentUserId, name: 'You' },
        receiver: { _id: receiverId },
        timestamp: new Date(),
        messageType: selectedFile ? attachment.type : 'text',
        attachment: selectedFile ? attachment : null,
        isTemporary: true,
        isRead: false
      };
      
      // Add temporary message to UI immediately
      if (onMessageSent) {
        onMessageSent(tempMessage);
      }
      
      // Clear input and reset state
      setMessage('');
      setSelectedFile(null);
      setPreviewUrl(null);
      
      // Reset textarea height
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
      
      // Stop typing indicator
      stopTyping(receiverId);
      setIsTyping(false);
      if (typingTimeout) {
        clearTimeout(typingTimeout);
        setTypingTimeout(null);
      }

      console.log('📤 Message sent:', messageToSend || 'File message');
    } catch (error) {
      console.error('❌ Error sending message:', error);
      console.error('❌ Error details:', {
        message: error.message,
        stack: error.stack,
        receiverId,
        messageToSend,
        selectedFile: !!selectedFile
      });
      setIsUploading(false);
      
      // Show user-friendly error message
      alert(`Failed to send message: ${error.message}`);
    }
  };

  const uploadFile = async (file) => {
    const formData = new FormData();
    formData.append('file', file);

    // Try multiple ways to get token
    let token = userToken || 
                localStorage.getItem('token') || 
                localStorage.getItem('authToken') || 
                sessionStorage.getItem('token') ||
                sessionStorage.getItem('authToken');
    
    console.log('🔑 Upload token check:');
    console.log('🔑 localStorage token:', localStorage.getItem('token') ? 'Exists' : 'Not found');
    console.log('🔑 sessionStorage token:', sessionStorage.getItem('token') ? 'Exists' : 'Not found');
    console.log('🔑 Final token:', token ? 'Found' : 'Not found');
    console.log('🔑 Token length:', token ? token.length : 0);
    
    if (!token) {
      console.log('❌ No token found in any storage');
      throw new Error('No authentication token found. Please login again.');
    }

    const response = await fetch(`${API_CONFIG.API_URL}/upload/file`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error('❌ Upload error response:', errorData);
      throw new Error(errorData.message || 'File upload failed');
    }

    const result = await response.json();
    console.log('✅ Upload successful:', result);
    
    // Return attachment object with proper structure
    const backendUrl = API_CONFIG.BASE_URL;
    
    const fullUrl = result.data.url.startsWith('http') ? result.data.url : `${backendUrl}${result.data.url}`;
    const fullThumbnailUrl = result.data.thumbnail ? 
      (result.data.thumbnail.startsWith('http') ? result.data.thumbnail : `${backendUrl}${result.data.thumbnail}`) : 
      null;
    
    const attachmentData = {
      url: fullUrl,
      filename: result.data.filename,
      originalName: result.data.originalName,
      mimeType: result.data.mimeType,
      size: result.data.size,
      thumbnail: fullThumbnailUrl,
      type: result.data.type,
      localPath: result.data.localPath // Store local path for reference
    };
    
    console.log('📎 Attachment data (Local URL):', attachmentData);
    console.log('📁 Local File URL:', attachmentData.url);
    return attachmentData;
  };


  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleInputChange = (e) => {
    const value = e.target.value;
    setMessage(value);

    // Auto-resize textarea
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }

    // Typing indicators
    if (value.trim() && !isTyping) {
      setIsTyping(true);
      startTyping(receiverId);
    }

    // Clear existing timeout
    if (typingTimeout) {
      clearTimeout(typingTimeout);
    }

    // Set new timeout to stop typing indicator
    const timeout = setTimeout(() => {
      setIsTyping(false);
      stopTyping(receiverId);
      setTypingTimeout(null);
    }, 1000);

    setTypingTimeout(timeout);
  };

  const handleInputBlur = () => {
    // Stop typing when input loses focus
    if (isTyping) {
      setIsTyping(false);
      stopTyping(receiverId);
    }
    if (typingTimeout) {
      clearTimeout(typingTimeout);
      setTypingTimeout(null);
    }
  };

  const handleFileSelect = (file) => {
    if (!file) return;

    // Validate file size (50MB limit)
    if (file.size > 50 * 1024 * 1024) {
      alert('File size must be less than 50MB');
      return;
    }

    // Validate file type
    const allowedTypes = [
      'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp',
      'video/mp4', 'video/avi', 'video/mov', 'video/wmv', 'video/flv', 'video/webm', 'video/mkv',
      'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'text/plain', 'text/csv', 'application/zip', 'application/x-rar-compressed', 'application/x-7z-compressed'
    ];

    if (!allowedTypes.includes(file.type)) {
      alert('File type not supported');
      return;
    }

    setSelectedFile(file);

    // Create preview for images
    if (file.type.startsWith('image/')) {
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const handleFileInputChange = (e) => {
    const file = e.target.files[0];
    handleFileSelect(file);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const removeSelectedFile = () => {
    setSelectedFile(null);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (typingTimeout) {
        clearTimeout(typingTimeout);
      }
    };
  }, [typingTimeout]);

  return (
    <div className="whatsapp-message-input-container relative">
      {/* File Preview */}
      {selectedFile && (
        <div className="whatsapp-file-preview">
          <div className="whatsapp-file-preview-content">
            <div className="whatsapp-file-preview-info">
              {previewUrl ? (
                <img
                  src={previewUrl}
                  alt="Preview"
                  className="whatsapp-file-preview-image"
                />
              ) : (
                <div className="whatsapp-file-preview-icon">
                  📎
                </div>
              )}
              <div className="whatsapp-file-preview-details">
                <div className="whatsapp-file-preview-name">
                  {selectedFile.name}
                </div>
                <div className="whatsapp-file-preview-size">
                  {formatFileSize(selectedFile.size)}
                </div>
              </div>
            </div>
            <button
              onClick={removeSelectedFile}
              className="whatsapp-file-remove-btn"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      <div 
        className={`whatsapp-message-input-wrapper ${
          dragOver ? 'whatsapp-drag-over' : ''
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div className="whatsapp-message-input-inner">
          {/* File Upload Button */}
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={disabled || isBlocked}
            className={`whatsapp-attach-btn ${
              (disabled || isBlocked) ? 'whatsapp-attach-btn-disabled' : ''
            }`}
            title={isBlocked ? `Cannot send files to blocked user` : "Attach file"}
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
              <path d="M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5c0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5c0 1.38 1.12 2.5 2.5 2.5s2.5-1.12 2.5-2.5V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6h-1.5z"/>
            </svg>
          </button>

          {/* Message Input Container */}
          <div className="whatsapp-input-container">
            <div className={`whatsapp-textarea-wrapper ${
              isBlocked ? 'whatsapp-blocked-input' : ''
            }`}>
              <textarea
                ref={textareaRef}
                value={message}
                onChange={handleInputChange}
                onKeyPress={handleKeyPress}
                onBlur={handleInputBlur}
                placeholder={isBlocked ? `${blockedUserName} is blocked` : "Type a message..."}
                disabled={disabled || isBlocked}
                rows={1}
                className={`whatsapp-message-textarea ${
                  disabled ? 'whatsapp-textarea-disabled' : ''
                }`}
                style={{
                  fontFamily: 'inherit',
                }}
              />
            </div>
          </div>

          {/* Send Button */}
          <button
            onClick={handleSendMessage}
            disabled={(!message.trim() && !selectedFile) || !receiverId || disabled || isUploading || isBlocked}
            className={`whatsapp-send-btn ${
              (message.trim() || selectedFile) && receiverId && !disabled && !isUploading && !isBlocked
                ? 'whatsapp-send-btn-active' 
                : 'whatsapp-send-btn-disabled'
            }`}
            title={isBlocked ? `Cannot send messages to blocked user` : "Send message"}
          >
            {isUploading ? (
              <div className="whatsapp-upload-spinner" />
            ) : (
              <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="currentColor"
                className="whatsapp-send-icon"
              >
                <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
              </svg>
            )}
          </button>
        </div>
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        onChange={handleFileInputChange}
        className="hidden"
        accept="image/*,video/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv,.zip,.rar,.7z"
      />

      {/* Drag overlay */}
      {dragOver && (
        <div className="whatsapp-drag-overlay">
          📎 Drop file here to attach
        </div>
      )}
    </div>
  );
};

export default MessageInput;
