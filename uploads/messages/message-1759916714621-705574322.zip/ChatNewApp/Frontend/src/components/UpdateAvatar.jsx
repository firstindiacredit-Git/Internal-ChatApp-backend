import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { API_CONFIG } from '../config/mobileConfig';
import Header from './Header';

const UpdateAvatar = ({ user: currentUser }) => {
  const navigate = useNavigate();
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef(null);

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        setError('Please select an image file (JPG, PNG, GIF)');
        return;
      }
      
      // Validate file size (max 5MB)
      const maxSize = 5 * 1024 * 1024; // 5MB
      if (file.size > maxSize) {
        const fileSizeMB = (file.size / (1024 * 1024)).toFixed(1);
        setError(`File size too large! Your file is ${fileSizeMB}MB. Maximum 5MB allowed for photo upload.`);
        return;
      }
      
      setSelectedFile(file);
      setError('');
      
      // Create preview URL
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreviewUrl(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;
    
    setLoading(true);
    setError('');
    
    try {
      // Create FormData for file upload
      const formData = new FormData();
      formData.append('avatar', selectedFile);
      
      // Get user token from localStorage
      const token = currentUser.token;
      if (!token) {
        setError('Authentication required. Please login again.');
        setLoading(false);
        return;
      }
      
      // Upload to backend API
      const response = await fetch(`${API_CONFIG.API_URL}/avatar/upload`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        // Handle specific error cases
        if (response.status === 413) {
          throw new Error('File size too large! Maximum 5MB allowed for photo upload.');
        } else if (response.status === 400) {
          throw new Error('Invalid file format. Please select JPG, PNG or GIF format photo.');
        } else if (response.status === 401) {
          throw new Error('Authentication required. Please login again.');
        } else {
          throw new Error(data.message || 'Avatar upload failed. Please try again.');
        }
      }
      
      // Update user avatar in localStorage
      const updatedUser = { ...currentUser, avatar: data.data.avatar };
      localStorage.setItem('user', JSON.stringify(updatedUser));
      
      // Show success message
      alert('✅ Avatar updated successfully!');
      
      // Navigate back to profile
      navigate(-1);
      
    } catch (err) {
      console.error('Avatar upload error:', err);
      setError(err.message || 'Avatar upload failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveAvatar = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setError('');
  };

  const handleDeleteAvatar = async () => {
    if (!currentUser.avatar) return;
    
    setLoading(true);
    setError('');
    
    try {
      // Get user token from localStorage
      const token = currentUser.token;
      if (!token) {
        setError('Authentication required. Please login again.');
        setLoading(false);
        return;
      }
      
      // Delete avatar from backend API
      const response = await fetch(`${API_CONFIG.API_URL}/avatar/delete`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Avatar delete failed. Please try again.');
      }
      
      // Update user avatar in localStorage
      const updatedUser = { ...currentUser, avatar: '' };
      localStorage.setItem('user', JSON.stringify(updatedUser));
      
      // Show success message
      alert('✅ Avatar deleted successfully!');
      
      // Navigate back to profile
      navigate(-1);
      
    } catch (err) {
      console.error('Avatar delete error:', err);
      setError(err.message || 'Avatar delete failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleBackClick = () => {
    navigate(-1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
        <Header 
          user={currentUser}
          title="📷 Update Avatar"
          showBackButton={true}
          onBackClick={handleBackClick}
          showActions={false}
        />

      <div className="pt-20 pb-8 px-4 max-w-md mx-auto">
        {/* Avatar Update Card */}
        <div className="bg-white rounded-3xl shadow-xl p-6 mb-6">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-2">
              📷 Update Avatar
            </h2>
            <p className="text-gray-600 text-sm">
              Change your profile photo
            </p>
          </div>
          
          {/* Current Avatar Display */}
          <div className="flex justify-center mb-6">
            <div className="relative">
              {previewUrl ? (
                <img 
                  src={previewUrl}
                  alt="Preview"
                  className="w-32 h-32 rounded-full border-4 border-whatsapp-green shadow-lg object-cover"
                />
              ) : currentUser.avatar ? (
                <img 
                  src={currentUser.avatar}
                  alt="Current Avatar"
                  className="w-32 h-32 rounded-full border-4 border-whatsapp-green shadow-lg object-cover"
                />
              ) : (
                <div className="w-32 h-32 rounded-full border-4 border-whatsapp-green shadow-lg bg-whatsapp-green flex items-center justify-center text-white text-4xl font-bold">
                  {currentUser.name?.charAt(0)?.toUpperCase() || 'U'}
                </div>
              )}
              
              {/* Camera Button */}
              <button
                onClick={() => fileInputRef.current?.click()}
                className="absolute -bottom-2 -right-2 w-10 h-10 bg-whatsapp-green hover:bg-whatsapp-dark text-white rounded-full flex items-center justify-center shadow-lg transition-colors duration-200"
                title="Select new photo"
              >
                📷
              </button>
            </div>
          </div>
          
          {/* File Input */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
          />
          
          {/* Error Message */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl">
              <p className="text-red-600 text-sm text-center">{error}</p>
            </div>
          )}
          
          {/* Action Buttons */}
          {selectedFile && (
            <div className="space-y-3 mb-4">
              <p className="text-center text-gray-600 text-sm">
                📁 Selected: {selectedFile.name}
              </p>
              
              <div className="flex gap-3">
                <button
                  onClick={handleUpload}
                  disabled={loading}
                  className="flex-1 bg-whatsapp-green hover:bg-whatsapp-dark text-white py-3 px-4 rounded-xl font-semibold transition-all duration-200 flex items-center justify-center gap-2 shadow-md hover:shadow-lg transform hover:-translate-y-0.5 disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                      Uploading...
                    </>
                  ) : (
                    <>
                      📤 Upload Avatar
                    </>
                  )}
                </button>
                
                <button
                  onClick={handleRemoveAvatar}
                  disabled={loading}
                  className="flex-1 bg-gray-500 hover:bg-gray-600 text-white py-3 px-4 rounded-xl font-semibold transition-all duration-200 flex items-center justify-center gap-2 shadow-md hover:shadow-lg transform hover:-translate-y-0.5 disabled:opacity-50"
                >
                  ❌ Cancel
                </button>
              </div>
            </div>
          )}
          
          {/* Instructions */}
          {!selectedFile && (
            <div className="text-center">
              <p className="text-gray-600 text-sm mb-4">
                📷 Click the camera icon to select a new photo
              </p>
              
              {currentUser.avatar && (
                <button
                  onClick={handleDeleteAvatar}
                  disabled={loading}
                  className="w-full bg-red-500 hover:bg-red-600 text-white py-3 px-4 rounded-xl font-semibold transition-all duration-200 flex items-center justify-center gap-2 shadow-md hover:shadow-lg transform hover:-translate-y-0.5 disabled:opacity-50 mb-4"
                >
                  {loading ? 'Deleting...' : '🗑️ Delete Current Avatar'}
                </button>
              )}
              
              <div className="bg-gray-50 rounded-xl p-4 text-center">
                <p className="text-gray-600 text-xs mb-1">
                  <strong>📁 Supported formats:</strong> JPG, PNG, GIF
                </p>
                <p className="text-gray-600 text-xs">
                  <strong>📏 Max size:</strong> 5MB
                </p>
              </div>
            </div>
          )}
        </div>
        
        {/* Tips Card */}
        <div className="bg-blue-50 rounded-2xl p-4 text-center">
          <div className="text-2xl mb-2">💡</div>
          <h3 className="text-sm font-semibold text-blue-800 mb-1">Tips</h3>
          <p className="text-xs text-blue-600 leading-relaxed">
            For best results, use a square photo. Photo should be clear and well-lit.
          </p>
        </div>
      </div>
    </div>
  );
};

export default UpdateAvatar;
