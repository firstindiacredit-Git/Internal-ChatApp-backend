import React, { useState } from 'react';
import WebRTCVideoCall from './WebRTCVideoCall';
import CallButton from './CallButton';

const VideoCallTest = () => {
  const [activeCall, setActiveCall] = useState(null);
  const [incomingCall, setIncomingCall] = useState(null);

  // Mock user data for testing
  const mockUser = {
    id: 'test-user-1',
    name: 'Test User',
    avatar: null,
    token: 'mock-token'
  };

  const mockOtherUser = {
    _id: 'test-user-2',
    name: 'Other User',
    avatar: null
  };

  const handleCallInitiated = (callData) => {
    console.log('Call initiated:', callData);
    setActiveCall({
      callId: 'test-call-' + Date.now(),
      callType: 'video',
      otherUser: mockOtherUser,
      status: 'outgoing'
    });
  };

  const handleCallEnd = () => {
    console.log('Call ended');
    setActiveCall(null);
    setIncomingCall(null);
  };

  const handleCallAnswer = () => {
    console.log('Call answered');
    if (incomingCall) {
      setIncomingCall(prev => ({
        ...prev,
        status: 'connected'
      }));
    }
  };

  const handleCallDecline = () => {
    console.log('Call declined');
    setIncomingCall(null);
  };

  const simulateIncomingCall = () => {
    setIncomingCall({
      callId: 'test-incoming-call-' + Date.now(),
      callType: 'video',
      caller: mockOtherUser,
      status: 'incoming'
    });
  };

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-center">Video Call Test</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Test Controls */}
        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Test Controls</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">Initiate Video Call</h3>
                <CallButton
                  user={mockUser}
                  otherUser={mockOtherUser}
                  callType="video"
                  onCallInitiated={handleCallInitiated}
                />
              </div>
              
              <div>
                <h3 className="font-medium mb-2">Simulate Incoming Call</h3>
                <button
                  onClick={simulateIncomingCall}
                  className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-colors"
                >
                  Simulate Incoming Video Call
                </button>
              </div>
              
              <div>
                <h3 className="font-medium mb-2">Clear All Calls</h3>
                <button
                  onClick={handleCallEnd}
                  className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg transition-colors"
                >
                  Clear All Calls
                </button>
              </div>
            </div>
          </div>

          {/* Call Status */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Call Status</h2>
            <div className="space-y-2">
              <p><strong>Active Call:</strong> {activeCall ? 'Yes' : 'No'}</p>
              <p><strong>Incoming Call:</strong> {incomingCall ? 'Yes' : 'No'}</p>
              {activeCall && (
                <div className="text-sm text-gray-600">
                  <p>Call ID: {activeCall.callId}</p>
                  <p>Type: {activeCall.callType}</p>
                  <p>Status: {activeCall.status}</p>
                </div>
              )}
              {incomingCall && (
                <div className="text-sm text-gray-600">
                  <p>Call ID: {incomingCall.callId}</p>
                  <p>Type: {incomingCall.callType}</p>
                  <p>Status: {incomingCall.status}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-semibold mb-4">Test Instructions</h2>
          <div className="space-y-4 text-sm">
            <div>
              <h3 className="font-medium text-green-600">✅ Features to Test:</h3>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>Video call initiation</li>
                <li>Incoming call simulation</li>
                <li>Call controls (mute, video toggle, screen share)</li>
                <li>Call end functionality</li>
                <li>Responsive design</li>
                <li>Error handling</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-blue-600">📋 Test Steps:</h3>
              <ol className="list-decimal list-inside space-y-1 mt-2">
                <li>Click "Video Call" to initiate a call</li>
                <li>Click "Simulate Incoming Call" to test incoming calls</li>
                <li>Test call controls during active calls</li>
                <li>Test call end functionality</li>
                <li>Test on different screen sizes</li>
              </ol>
            </div>
            
            <div>
              <h3 className="font-medium text-orange-600">⚠️ Note:</h3>
              <p className="mt-2">
                This is a test component. In a real application, video calls would require:
              </p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>WebRTC peer connection</li>
                <li>Socket.io for signaling</li>
                <li>Camera/microphone permissions</li>
                <li>STUN/TURN servers for NAT traversal</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Video Call Components */}
      {activeCall && (
        <WebRTCVideoCall
          user={mockUser}
          callData={activeCall}
          isIncoming={false}
          onCallEnd={handleCallEnd}
          onCallAnswer={handleCallAnswer}
          onCallDecline={handleCallDecline}
        />
      )}

      {incomingCall && (
        <WebRTCVideoCall
          user={mockUser}
          callData={incomingCall}
          isIncoming={true}
          onCallEnd={handleCallEnd}
          onCallAnswer={handleCallAnswer}
          onCallDecline={handleCallDecline}
        />
      )}
    </div>
  );
};

export default VideoCallTest;
