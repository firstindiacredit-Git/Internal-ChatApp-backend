import React, { useState, useEffect, useRef } from 'react';
import getFirebaseApp from '../services/firebase';
import { getFirestore, doc, setDoc, updateDoc, onSnapshot, collection, addDoc } from 'firebase/firestore';
import { useSocket } from '../contexts/SocketContext';

const WebRTCVideoCall = ({ 
  user, 
  callData, 
  isIncoming = false, 
  onCallEnd, 
  onCallAnswer,
  onCallDecline 
}) => {
  const { socket, isConnected } = useSocket();
  const [callStatus, setCallStatus] = useState(isIncoming ? 'incoming' : 'outgoing');
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [error, setError] = useState(null);
  const [connectionQuality, setConnectionQuality] = useState('good');

  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);
  const remoteStreamRef = useRef(null);
  const localStreamRef = useRef(null);
  const screenStreamRef = useRef(null);
  const peerConnectionRef = useRef(null);
  const callStartTimeRef = useRef(null);
  const durationIntervalRef = useRef(null);
  const answerProcessedRef = useRef(false);
  const processedCallIdRef = useRef(null);
  const callEndedRef = useRef(false);
  const offerCreatedRef = useRef(false);
  const iceCandidateQueueRef = useRef([]);
  const webrtcInitializedRef = useRef(false);
  const remotePlayInProgressRef = useRef(false);
  const latestOfferRef = useRef(null);
  const pendingAutoAnswerRef = useRef(false);
  const firebaseEnabledRef = useRef(false);
  const roomRefRef = useRef(null);

  // WebRTC configuration with STUN and optional TURN from env
  const rtcConfiguration = React.useMemo(() => {
    const servers = [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      { urls: 'stun:stun2.l.google.com:19302' },
      { urls: 'stun:stun3.l.google.com:19302' },
      { urls: 'stun:stun4.l.google.com:19302' },
    ];
    const turnUrl = import.meta.env.VITE_TURN_URL;
    const turnUsername = import.meta.env.VITE_TURN_USERNAME;
    const turnCredential = import.meta.env.VITE_TURN_CREDENTIAL;
    if (turnUrl && turnUsername && turnCredential) {
      servers.push({ urls: turnUrl, username: turnUsername, credential: turnCredential });
      console.log('🌀 Using TURN server');
    } else {
      console.log('🌀 TURN not configured; using STUN only');
    }
    return {
      iceServers: servers,
      iceCandidatePoolSize: 10,
    };
  }, []);

  // Initialize WebRTC
  useEffect(() => {
    if (callData && callData.callId && isConnected) {
      initializeWebRTC();
    }

    return () => {
      cleanup();
    };
  }, [callData, isConnected]);

  // Update call duration
  useEffect(() => {
    if (callStatus === 'connected' && callStartTimeRef.current) {
      durationIntervalRef.current = setInterval(() => {
        const duration = Math.floor((Date.now() - callStartTimeRef.current) / 1000);
        setCallDuration(duration);
      }, 1000);
    } else {
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
        durationIntervalRef.current = null;
      }
    }

    return () => {
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
      }
    };
  }, [callStatus]);

  const initializeWebRTC = async () => {
    try {
      console.log('📹 Initializing WebRTC for video call');
      
      // Reset flags
      answerProcessedRef.current = false;
      processedCallIdRef.current = null;
      callEndedRef.current = false;
      offerCreatedRef.current = false;
      iceCandidateQueueRef.current = [];
      webrtcInitializedRef.current = false;
      
      // Get user media with video
      const constraints = {
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
        video: {
          width: { ideal: 1280, max: 1920 },
          height: { ideal: 720, max: 1080 },
          frameRate: { ideal: 30, max: 60 },
          facingMode: 'user'
        },
      };
      
      console.log('📹 Media constraints:', constraints);
      
      try {
        localStreamRef.current = await navigator.mediaDevices.getUserMedia(constraints);
        console.log('📹 Local stream obtained:', localStreamRef.current);
      } catch (mediaError) {
        console.error('📹 Media access error:', mediaError);
        
        if (mediaError.name === 'NotAllowedError') {
          setError('Camera/microphone access denied. Please allow access and try again.');
        } else if (mediaError.name === 'NotFoundError') {
          setError('Camera/microphone not found. Please check your devices.');
        } else if (mediaError.name === 'NotReadableError') {
          setError('Camera/microphone is being used by another application.');
        } else {
          setError(`Media access failed: ${mediaError.message}`);
        }
        return;
      }
      
      // Set up local video with stable playback
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = localStreamRef.current;
        localVideoRef.current.setAttribute('playsinline', 'true');
        localVideoRef.current.setAttribute('autoplay', 'true');
        localVideoRef.current.muted = true; // Always mute local video to prevent feedback
        
        // Safe play with retry on AbortError
        const playLocalVideo = () => {
          if (localVideoRef.current) {
            localVideoRef.current.play().catch(e => {
              if (e.name === 'AbortError') {
                // Retry after a short delay
                setTimeout(() => {
                  if (localVideoRef.current) {
                    localVideoRef.current.play().catch(err => 
                      console.warn('📹 Local video play retry failed:', err?.name || err)
                    );
                  }
                }, 100);
              } else {
                console.warn('📹 Local video play error:', e?.name || e);
              }
            });
          }
        };
        
        // Try to play immediately and on metadata load
        playLocalVideo();
        localVideoRef.current.onloadedmetadata = playLocalVideo;
      }

      // Create peer connection
      try {
        peerConnectionRef.current = new RTCPeerConnection(rtcConfiguration);
        console.log('📹 Peer connection created successfully');
      } catch (pcError) {
        console.error('📹 Peer connection creation error:', pcError);
        setError(`Failed to create peer connection: ${pcError.message}`);
        return;
      }

      // Pre-create transceivers to ensure bidirectional A/V even if tracks arrive later
      try {
        if (peerConnectionRef.current.addTransceiver) {
          peerConnectionRef.current.addTransceiver('audio', { direction: 'sendrecv' });
          peerConnectionRef.current.addTransceiver('video', { direction: 'sendrecv' });
          console.log('📹 Transceivers added (audio/video sendrecv)');
        }
      } catch (txErr) {
        console.warn('📹 Failed to add transceivers (non-fatal):', txErr);
      }

      // Add local stream to peer connection
      try {
        localStreamRef.current.getTracks().forEach(track => {
          console.log('📹 Adding track to peer connection:', track.kind, track.label);
          peerConnectionRef.current.addTrack(track, localStreamRef.current);
        });
        console.log('📹 All tracks added to peer connection successfully');
      } catch (trackError) {
        console.error('📹 Track addition error:', trackError);
        setError(`Failed to add tracks to peer connection: ${trackError.message}`);
        return;
      }

      // Prepare remote MediaStream once and reuse
      if (!remoteStreamRef.current) {
        remoteStreamRef.current = new MediaStream();
      } else {
        // Clear any existing tracks to avoid duplicates between calls
        remoteStreamRef.current.getTracks().forEach(t => remoteStreamRef.current.removeTrack(t));
      }

      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = remoteStreamRef.current;
        // Ensure inline/autoplay attributes (iOS Safari friendliness)
        remoteVideoRef.current.setAttribute('playsinline', 'true');
        remoteVideoRef.current.setAttribute('autoplay', 'true');
        // Try to play once metadata is ready
        remoteVideoRef.current.onloadedmetadata = () => {
          if (!remotePlayInProgressRef.current) {
            remotePlayInProgressRef.current = true;
            remoteVideoRef.current.play().catch(e => {
              console.warn('📹 Remote video play deferred (metadata):', e?.name || e);
              remotePlayInProgressRef.current = false;
            });
          }
        };
      }

      const safePlayRemote = () => {
        const el = remoteVideoRef.current;
        if (!el) return;
        if (!remotePlayInProgressRef.current) {
          remotePlayInProgressRef.current = true;
          el.play().catch(e => {
            // AbortError typically due to srcObject update race; retry shortly
            if (e && e.name === 'AbortError') {
              setTimeout(() => {
                el.play().catch(err => console.warn('📹 Remote play retry failed:', err?.name || err));
              }, 100);
            } else {
              console.warn('📹 Remote video play error:', e?.name || e);
            }
            remotePlayInProgressRef.current = false;
          });
        }
      };

      // Handle remote stream tracks by adding to persistent MediaStream
      peerConnectionRef.current.ontrack = (event) => {
        const [stream] = event.streams;
        console.log('📹 Received remote track:', event.track?.kind, 'readyState:', event.track?.readyState);

        const attach = () => {
          if (remoteStreamRef.current) {
            if (!remoteStreamRef.current.getTracks().includes(event.track)) {
              remoteStreamRef.current.addTrack(event.track);
            }
          }
          if (remoteVideoRef.current && remoteVideoRef.current.srcObject !== remoteStreamRef.current) {
            remoteVideoRef.current.srcObject = remoteStreamRef.current;
          }
          if (remoteVideoRef.current && remoteVideoRef.current.volume !== undefined) {
            remoteVideoRef.current.volume = 1.0;
          }
          safePlayRemote();
        };

        // Some browsers deliver tracks muted first. Wait for unmute before attaching.
        if (event.track && event.track.muted) {
          event.track.onunmute = () => {
            console.log('📹 Remote track unmuted:', event.track.kind);
            attach();
          };
        } else {
          attach();
        }
      };

      // Handle ICE candidates
      peerConnectionRef.current.onicecandidate = (event) => {
        if (event.candidate && socket) {
          console.log('🧊 Sending ICE candidate:', event.candidate.type);
          socket.emit('ice-candidate', {
            callId: callData.callId,
            candidate: event.candidate.candidate,
            sdpMLineIndex: event.candidate.sdpMLineIndex,
            sdpMid: event.candidate.sdpMid,
          });
        } else if (event.candidate === null) {
          console.log('🧊 ICE gathering complete');
        }
      };

      // Handle connection state changes
      peerConnectionRef.current.onconnectionstatechange = () => {
        const state = peerConnectionRef.current.connectionState;
        console.log('📹 Connection state changed:', state);
        
        if (state === 'connected') {
          setCallStatus('connected');
          callStartTimeRef.current = Date.now();
          setConnectionQuality('excellent');
        } else if (state === 'disconnected' || state === 'failed') {
          setConnectionQuality('poor');
          handleCallEnd();
        } else if (state === 'connecting') {
          setConnectionQuality('fair');
        }
      };

      // Handle ICE connection state changes
      peerConnectionRef.current.oniceconnectionstatechange = () => {
        const state = peerConnectionRef.current.iceConnectionState;
        console.log('🧊 ICE connection state:', state);
        
        if (state === 'connected' || state === 'completed') {
          setConnectionQuality('excellent');
        } else if (state === 'checking') {
          setConnectionQuality('good');
        } else if (state === 'disconnected' || state === 'failed') {
          setConnectionQuality('poor');
          // Try ICE restart once if connection drops
          if (peerConnectionRef.current && peerConnectionRef.current.restartIce) {
            try {
              console.log('🧊 Restarting ICE');
              peerConnectionRef.current.restartIce();
            } catch (e) {
              console.warn('🧊 ICE restart failed:', e);
            }
          }
        }
      };

      // Initialize optional Firebase signaling (in parallel with socket)
      try {
        const useFirebase = String(import.meta.env.VITE_USE_FIREBASE_SIGNALING || '').toLowerCase() === 'true';
        const app = getFirebaseApp();
        if (useFirebase && app) {
          const db = getFirestore(app);
          firebaseEnabledRef.current = true;
          // Create a room doc for this call id if not exists
          const roomDocRef = doc(db, 'webrtc_rooms', String(callData.callId));
          await setDoc(roomDocRef, { createdAt: Date.now() }, { merge: true });
          roomRefRef.current = roomDocRef;

          // Listen for remote offer/answer and candidates
          onSnapshot(roomDocRef, async (snap) => {
            const data = snap.data();
            if (!data) return;
            // If we are caller and receive answer via Firestore, set it
            if (!isIncoming && data.answer && peerConnectionRef.current && peerConnectionRef.current.signalingState === 'have-local-offer') {
              try {
                await peerConnectionRef.current.setRemoteDescription(data.answer);
                console.log('📡 Firebase: remote answer applied');
                await processQueuedIceCandidates();
              } catch {}
            }
            // If we are receiver and receive offer via Firestore, set it
            if (isIncoming && data.offer && peerConnectionRef.current && peerConnectionRef.current.signalingState === 'stable') {
              try {
                await peerConnectionRef.current.setRemoteDescription(data.offer);
                console.log('📡 Firebase: remote offer applied');
                await processQueuedIceCandidates();
              } catch {}
            }
          });

          // Listen to ICE candidates from other side
          const remoteCandidatesCol = collection(roomDocRef, isIncoming ? 'callerCandidates' : 'receiverCandidates');
          onSnapshot(remoteCandidatesCol, (snap) => {
            snap.docChanges().forEach(async (change) => {
              if (change.type === 'added') {
                const candidateData = change.doc.data();
                try {
                  await peerConnectionRef.current.addIceCandidate(candidateData);
                } catch {}
              }
            });
          });

          // On our ICE candidates, write to Firestore too
          const localCandidatesCol = collection(roomDocRef, isIncoming ? 'receiverCandidates' : 'callerCandidates');
          peerConnectionRef.current.onicecandidate = (event) => {
            if (event.candidate && socket) {
              console.log('🧊 Sending ICE candidate:', event.candidate.type);
              socket.emit('ice-candidate', {
                callId: callData.callId,
                candidate: event.candidate.candidate,
                sdpMLineIndex: event.candidate.sdpMLineIndex,
                sdpMid: event.candidate.sdpMid,
              });
              // Also write to Firestore
              addDoc(localCandidatesCol, event.candidate.toJSON()).catch(() => {});
            } else if (event.candidate === null) {
              console.log('🧊 ICE gathering complete');
            }
          };
        }
      } catch (e) {
        console.warn('📡 Firebase signaling init skipped/failed:', e?.message || e);
      }

      // Set up socket event listeners
      setupSocketListeners();

      // Mark WebRTC as initialized
      webrtcInitializedRef.current = true;
      console.log('📹 WebRTC initialization completed successfully');

      // For outgoing calls, create and send offer
      if (!isIncoming) {
        await createAndSendOffer();
      }

    } catch (error) {
      console.error('Error initializing WebRTC:', error);
      webrtcInitializedRef.current = false;
      setError('Failed to access camera/microphone. Please check permissions.');
    }
  };

  const setupSocketListeners = () => {
    if (!socket) return;

    console.log('📹 Setting up socket listeners for call:', callData.callId);

    // Remove existing listeners to prevent duplicates
    socket.off('call-answered');
    socket.off('call-declined');
    socket.off('call-ended');
    socket.off('call-error');
    socket.off('call-offer');
    socket.off('ice-candidate');

    // Handle incoming call answer
    socket.on('call-answered', async (data) => {
      if (data.callId === callData.callId) {
        console.log('📹 Received call-answered event:', data);
        
        if (processedCallIdRef.current === data.callId) {
          console.log('📹 Answer for this call already processed, skipping');
          return;
        }
        
        try {
          if (data.answer && peerConnectionRef.current) {
            const parsedAnswer = typeof data.answer === 'string' ? JSON.parse(data.answer) : data.answer;
            const currentState = peerConnectionRef.current.signalingState;
            
            if (currentState === 'have-local-offer' && !answerProcessedRef.current) {
              await peerConnectionRef.current.setRemoteDescription(parsedAnswer);
              answerProcessedRef.current = true;
              processedCallIdRef.current = data.callId;
              console.log('📹 Remote answer set successfully');
              
              await processQueuedIceCandidates();
            }
          }
          
          setCallStatus('connected');
          callStartTimeRef.current = Date.now();
          // Try to play remote video after answer is processed
          if (remoteVideoRef.current) {
            remoteVideoRef.current.play().catch(e => console.warn('📹 Remote play after answer error:', e?.name || e));
          }
        } catch (error) {
          console.error('Error handling call answer:', error);
          setError('Failed to handle call answer');
        }
      }
    });

    // Handle call declined
    socket.on('call-declined', (data) => {
      if (data.callId === callData.callId) {
        setCallStatus('declined');
        setTimeout(() => {
          onCallEnd();
        }, 2000);
      }
    });

    // Handle call ended
    socket.on('call-ended', (data) => {
      if (data.callId === callData.callId) {
        handleCallEnd();
      }
    });

    // Handle ICE candidates
    socket.on('ice-candidate', async (data) => {
      if (data.callId === callData.callId && peerConnectionRef.current) {
        try {
          const currentState = peerConnectionRef.current.signalingState;
          const hasRemoteDescription = peerConnectionRef.current.remoteDescription !== null;
          
          // Only add ICE candidates if we have a remote description
          if (hasRemoteDescription && (currentState === 'stable' || currentState === 'have-local-offer' || currentState === 'have-remote-offer')) {
            console.log('🧊 Adding ICE candidate');
            await peerConnectionRef.current.addIceCandidate({
              candidate: data.candidate,
              sdpMLineIndex: data.sdpMLineIndex,
              sdpMid: data.sdpMid,
            });
          } else {
            console.log('🧊 Buffering ICE candidate (no remote description yet)');
            iceCandidateQueueRef.current.push({
              candidate: data.candidate,
              sdpMLineIndex: data.sdpMLineIndex,
              sdpMid: data.sdpMid,
            });
          }
        } catch (error) {
          console.error('Error adding ICE candidate:', error);
        }
      }
    });

    // Handle call errors
    socket.on('call-error', (data) => {
      setError(data.error);
    });

    // Handle receiving offer for incoming calls
    socket.on('call-offer', async (data) => {
      if (data.callId === callData.callId && isIncoming) {
        try {
          const offer = typeof data.offer === 'string' ? JSON.parse(data.offer) : data.offer;
          latestOfferRef.current = offer;
          
          if (peerConnectionRef.current) {
            const currentState = peerConnectionRef.current.signalingState;
            
            if (currentState === 'stable') {
              await peerConnectionRef.current.setRemoteDescription(offer);
              console.log('📹 Remote offer set successfully');
              
              await processQueuedIceCandidates();
              // Attempt to play remote after setting offer (some browsers require this kick)
              if (remoteVideoRef.current) {
                remoteVideoRef.current.play().catch(e => console.warn('📹 Remote play after offer error:', e?.name || e));
              }

              // If user tapped Answer before offer arrived, auto-answer now
              if (pendingAutoAnswerRef.current) {
                pendingAutoAnswerRef.current = false;
                try {
                  const answer = await peerConnectionRef.current.createAnswer();
                  await peerConnectionRef.current.setLocalDescription(answer);
                  socket.emit('call-answer', {
                    callId: callData.callId,
                    answer: answer,
                  });
                  setCallStatus('connected');
                  callStartTimeRef.current = Date.now();
                  onCallAnswer && onCallAnswer();
                  console.log('📹 Auto-answered after offer arrival');
                } catch (e) {
                  console.error('📹 Auto-answer failed:', e);
                }
              }
            }
          }
        } catch (error) {
          console.error('Error handling incoming offer:', error);
          setError('Failed to handle call offer');
        }
      }
    });
  };

  const processQueuedIceCandidates = async () => {
    if (iceCandidateQueueRef.current.length > 0) {
      console.log('🧊 Processing queued ICE candidates:', iceCandidateQueueRef.current.length);
      for (const candidate of iceCandidateQueueRef.current) {
        try {
          await peerConnectionRef.current.addIceCandidate(candidate);
        } catch (error) {
          console.error('Error adding queued ICE candidate:', error);
        }
      }
      iceCandidateQueueRef.current = [];
    }
  };

  const createAndSendOffer = async () => {
    try {
      console.log('📹 Starting offer creation process...');
      
      if (!webrtcInitializedRef.current || !peerConnectionRef.current || !socket || !callData?.callId) {
        setError('WebRTC not ready for offer creation');
        return;
      }
      
      if (offerCreatedRef.current) {
        console.log('📹 Offer already created, skipping');
        return;
      }
      
      const currentState = peerConnectionRef.current.signalingState;
      if (currentState !== 'stable') {
        console.log(`📹 Cannot create offer in state: ${currentState}, waiting...`);
        // Wait a bit and retry if in wrong state
        setTimeout(() => {
          if (peerConnectionRef.current && peerConnectionRef.current.signalingState === 'stable') {
            createAndSendOffer();
          }
        }, 500);
        return;
      }
      
      console.log('📹 Creating WebRTC offer...');
      const offer = await peerConnectionRef.current.createOffer();
      
      // Check if we're still in stable state before setting local description
      if (peerConnectionRef.current.signalingState !== 'stable') {
        console.log('📹 Signaling state changed during offer creation, aborting');
        return;
      }
      
      await peerConnectionRef.current.setLocalDescription(offer);
      offerCreatedRef.current = true;

      socket.emit('call-offer', {
        callId: callData.callId,
        offer: offer,
      });

      // If Firebase signaling enabled, store offer in room doc
      if (firebaseEnabledRef.current && roomRefRef.current) {
        try {
          await updateDoc(roomRefRef.current, { offer });
          console.log('📡 Firebase: offer saved');
        } catch {}
      }

      setCallStatus('ringing');
      console.log('📹 Offer created and sent successfully');
    } catch (error) {
      console.error('Error creating and sending offer:', error);
      if (error.name === 'InvalidModificationError') {
        console.log('📹 SDP mismatch detected, resetting offer creation flag');
        offerCreatedRef.current = false;
        // Retry after a short delay
        setTimeout(() => {
          if (peerConnectionRef.current && peerConnectionRef.current.signalingState === 'stable') {
            createAndSendOffer();
          }
        }, 1000);
      } else {
        setError(`Failed to create call offer: ${error.message}`);
      }
    }
  };

  const handleCallAnswer = async () => {
    try {
      if (peerConnectionRef.current) {
        let currentState = peerConnectionRef.current.signalingState;

        // If no remote offer applied yet but we have a buffered one, apply it now
        if (currentState === 'stable' && latestOfferRef.current) {
          try {
            await peerConnectionRef.current.setRemoteDescription(latestOfferRef.current);
            console.log('📹 Applied buffered remote offer before answering');
            await processQueuedIceCandidates();
            currentState = peerConnectionRef.current.signalingState;
          } catch (e) {
            console.error('📹 Failed to apply buffered offer:', e);
          }
        }

        if (currentState === 'have-remote-offer') {
          const answer = await peerConnectionRef.current.createAnswer();
          await peerConnectionRef.current.setLocalDescription(answer);

          socket.emit('call-answer', {
            callId: callData.callId,
            answer: answer,
          });

          // If Firebase signaling enabled, store answer in room doc
          if (firebaseEnabledRef.current && roomRefRef.current) {
            try {
              await updateDoc(roomRefRef.current, { answer });
              console.log('📡 Firebase: answer saved');
            } catch {}
          }

          setCallStatus('connected');
          callStartTimeRef.current = Date.now();
          onCallAnswer && onCallAnswer();
          console.log('📹 Answer created and sent successfully');
        } else if (currentState === 'stable' && !latestOfferRef.current) {
          // Offer hasn't arrived yet. Queue auto-answer once it arrives.
          pendingAutoAnswerRef.current = true;
          console.log('📹 Offer not yet received; queued auto-answer');
        } else {
          setError('Cannot answer call in current state');
        }
      } else {
        setError('Call connection not ready');
      }
    } catch (error) {
      console.error('Error answering call:', error);
      setError('Failed to answer call');
    }
  };

  const handleCallDecline = () => {
    if (socket) {
      socket.emit('call-decline', {
        callId: callData.callId,
      });
    }
    setCallStatus('declined');
    onCallDecline && onCallDecline();
    setTimeout(() => {
      onCallEnd();
    }, 1000);
  };

  const handleCallEnd = () => {
    if (callEndedRef.current) {
      console.log('📹 Call already ended, skipping duplicate end');
      return;
    }
    
    callEndedRef.current = true;
    
    if (socket) {
      socket.emit('call-end', {
        callId: callData.callId,
      });
    }
    setCallStatus('ended');
    onCallEnd && onCallEnd();
  };

  const toggleMute = () => {
    if (localStreamRef.current) {
      const audioTracks = localStreamRef.current.getAudioTracks();
      audioTracks.forEach(track => {
        track.enabled = isMuted;
      });
      setIsMuted(!isMuted);
    }
  };

  const toggleVideo = () => {
    if (localStreamRef.current) {
      const videoTracks = localStreamRef.current.getVideoTracks();
      const newVideoState = !isVideoEnabled;
      
      videoTracks.forEach(track => {
        track.enabled = newVideoState;
      });
      
      setIsVideoEnabled(newVideoState);
    }
  };

  const toggleScreenShare = async () => {
    try {
      if (isScreenSharing) {
        // Stop screen sharing
        if (screenStreamRef.current) {
          screenStreamRef.current.getTracks().forEach(track => track.stop());
          screenStreamRef.current = null;
        }
        
        // Replace with camera stream
        const constraints = {
          audio: true,
          video: { width: 1280, height: 720, frameRate: 30 }
        };
        const newStream = await navigator.mediaDevices.getUserMedia(constraints);
        
        // Replace video track
        const videoTrack = newStream.getVideoTracks()[0];
        const sender = peerConnectionRef.current.getSenders().find(s => 
          s.track && s.track.kind === 'video'
        );
        if (sender) {
          await sender.replaceTrack(videoTrack);
        }
        
        localStreamRef.current = newStream;
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = newStream;
        }
        
        setIsScreenSharing(false);
      } else {
        // Start screen sharing
        const screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: true
        });
        
        // Replace video track with screen share
        const videoTrack = screenStream.getVideoTracks()[0];
        const sender = peerConnectionRef.current.getSenders().find(s => 
          s.track && s.track.kind === 'video'
        );
        if (sender) {
          await sender.replaceTrack(videoTrack);
        }
        
        screenStreamRef.current = screenStream;
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = screenStream;
        }
        
        setIsScreenSharing(true);
        
        // Handle screen share end
        videoTrack.onended = () => {
          toggleScreenShare();
        };
      }
    } catch (error) {
      console.error('Error toggling screen share:', error);
      setError('Failed to toggle screen sharing');
    }
  };

  const cleanup = () => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => track.stop());
    }
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach(track => track.stop());
    }
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
    }
    if (durationIntervalRef.current) {
      clearInterval(durationIntervalRef.current);
    }
  };

  const formatDuration = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getConnectionQualityColor = () => {
    switch (connectionQuality) {
      case 'excellent': return 'text-green-400';
      case 'good': return 'text-yellow-400';
      case 'fair': return 'text-orange-400';
      case 'poor': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  if (error) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50">
        <div className="bg-white rounded-2xl p-8 max-w-sm w-full mx-4 text-center">
          <div className="text-6xl mb-4">❌</div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Call Error</h3>
          <p className="text-gray-600 mb-6">{error}</p>
          <button 
            onClick={onCallEnd}
            className="bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black flex flex-col z-50">
      {/* Video streams */}
      <div className="flex-1 relative">
        {/* Remote video (main) */}
        <video
          ref={remoteVideoRef}
          autoPlay
          playsInline
          className="w-full h-full object-cover"
          onLoadedMetadata={() => console.log('📹 Remote video loaded')}
        />
        
        {/* Local video (picture-in-picture) */}
        <div className="absolute top-4 right-4 w-48 h-36 bg-gray-800 rounded-lg overflow-hidden shadow-lg">
          <video
            ref={localVideoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
            onLoadedMetadata={() => console.log('📹 Local video loaded')}
          />
          {!isVideoEnabled && (
            <div className="absolute inset-0 bg-gray-800 flex items-center justify-center">
              <div className="text-white text-center">
                <div className="text-2xl mb-2">📹❌</div>
                <div className="text-xs">Video Off</div>
              </div>
            </div>
          )}
        </div>

        {/* Call info overlay */}
        <div className="absolute top-4 left-4 text-white">
          <div className="bg-black bg-opacity-50 rounded-lg p-3">
            <h2 className="text-lg font-semibold">
              {callData?.otherUser?.name || callData?.receiver?.name || callData?.caller?.name || 'Unknown'}
            </h2>
            <p className="text-sm text-gray-300">
              {callStatus === 'incoming' && 'Incoming video call...'}
              {callStatus === 'outgoing' && 'Calling...'}
              {callStatus === 'ringing' && 'Ringing...'}
              {callStatus === 'connected' && `Connected - ${formatDuration(callDuration)}`}
              {callStatus === 'declined' && 'Call declined'}
              {callStatus === 'ended' && 'Call ended'}
            </p>
            {callStatus === 'connected' && (
              <div className={`text-xs ${getConnectionQualityColor()}`}>
                Quality: {connectionQuality}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Call controls */}
      <div className="bg-black bg-opacity-80 p-6">
        <div className="flex justify-center items-center gap-4">
          {callStatus === 'incoming' && (
            <>
              <button 
                className="w-16 h-16 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center text-2xl transition-colors shadow-lg"
                onClick={handleCallDecline}
                title="Decline"
              >
                📞❌
              </button>
              <button 
                className="w-16 h-16 bg-green-500 hover:bg-green-600 text-white rounded-full flex items-center justify-center text-2xl transition-colors shadow-lg"
                onClick={handleCallAnswer}
                title="Answer"
              >
                📞✅
              </button>
            </>
          )}

          {callStatus === 'connected' && (
            <>
              <button 
                className={`w-14 h-14 rounded-full flex items-center justify-center text-xl transition-all shadow-lg ${
                  isMuted 
                    ? 'bg-red-500 hover:bg-red-600 text-white' 
                    : 'bg-white bg-opacity-20 hover:bg-opacity-30 text-white'
                }`}
                onClick={toggleMute}
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? '🔇' : '🎤'}
              </button>
              
              <button 
                className={`w-14 h-14 rounded-full flex items-center justify-center text-xl transition-all shadow-lg ${
                  !isVideoEnabled 
                    ? 'bg-red-500 hover:bg-red-600 text-white' 
                    : 'bg-white bg-opacity-20 hover:bg-opacity-30 text-white'
                }`}
                onClick={toggleVideo}
                title={isVideoEnabled ? 'Disable Video' : 'Enable Video'}
              >
                {isVideoEnabled ? '📹' : '📹❌'}
              </button>

              <button 
                className={`w-14 h-14 rounded-full flex items-center justify-center text-xl transition-all shadow-lg ${
                  isScreenSharing 
                    ? 'bg-blue-500 hover:bg-blue-600 text-white' 
                    : 'bg-white bg-opacity-20 hover:bg-opacity-30 text-white'
                }`}
                onClick={toggleScreenShare}
                title={isScreenSharing ? 'Stop Sharing' : 'Share Screen'}
              >
                {isScreenSharing ? '🖥️' : '📺'}
              </button>
              
              <button 
                className="w-16 h-16 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center text-2xl transition-colors shadow-lg"
                onClick={handleCallEnd}
                title="End Call"
              >
                📞❌
              </button>
            </>
          )}

          {(callStatus === 'outgoing' || callStatus === 'ringing') && (
            <button 
              className="w-16 h-16 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center text-2xl transition-colors shadow-lg"
              onClick={handleCallEnd}
              title="Cancel Call"
            >
              📞❌
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default WebRTCVideoCall;
