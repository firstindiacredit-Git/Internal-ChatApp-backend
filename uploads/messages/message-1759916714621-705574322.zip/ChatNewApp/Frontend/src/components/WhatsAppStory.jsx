import React, { useState, useEffect, useRef } from 'react';
import { API_CONFIG } from '../config/mobileConfig';
import { useSocket } from '../contexts/SocketContext';
import { Button, Input, Card, Avatar, Typography, Space, Row, Col, Tooltip, Slider, Dropdown } from 'antd';
import { 
  PlusOutlined, 
  EditOutlined, 
  CameraOutlined, 
  VideoCameraOutlined,
  EyeOutlined,
  DeleteOutlined,
  HeartOutlined,
  MessageOutlined,
  SendOutlined,
  BgColorsOutlined,
  FontSizeOutlined,
  CloseOutlined,
  SmileOutlined,
  PaperClipOutlined,
  AudioOutlined
} from '@ant-design/icons';

const { Text, Title } = Typography;

const WhatsAppStory = ({ user, onBack }) => {
  const { socket, isConnected } = useSocket();
  const [stories, setStories] = useState([]);
  const [myStories, setMyStories] = useState([]);
  const [showStoryViewer, setShowStoryViewer] = useState(false);
  const [selectedUserStories, setSelectedUserStories] = useState(null);
  const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
  const [showCreateStory, setShowCreateStory] = useState(false);
  const [storyType, setStoryType] = useState('text');
  const [newStoryContent, setNewStoryContent] = useState('');
  const [uploadedMedia, setUploadedMedia] = useState(null);
  const [mediaPreview, setMediaPreview] = useState('');
  const [selectedBackgroundColor, setSelectedBackgroundColor] = useState('#25D366');
  const [textColor, setTextColor] = useState('#ffffff');
  const [textSize, setTextSize] = useState('medium');
  const [showStoryOptions, setShowStoryOptions] = useState(false);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showTextStyling, setShowTextStyling] = useState(false);
  const [storyLikes, setStoryLikes] = useState({});
  const [storyComments, setStoryComments] = useState({});
  const [showComments, setShowComments] = useState(false);
  const [currentStoryComments, setCurrentStoryComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [showViewers, setShowViewers] = useState(false);
  const [storyViewers, setStoryViewers] = useState([]);
  
  const fileInputRef = useRef(null);
  const commentInputRef = useRef(null);
  const storyViewerRef = useRef(null);
  const progressIntervalRef = useRef(null);

  // Helper function to get color position for selector
  const getColorPosition = (color) => {
    if (!color || !color.includes('hsl')) return 0;
    const match = color.match(/\d+/);
    if (!match) return 0;
    return (parseFloat(match[0]) / 360) * 100;
  };

  // Fetch stories feed
  const fetchStories = async () => {
    try {
      const response = await fetch(`${API_CONFIG.API_URL}/stories/feed`, {
        headers: {
          'Authorization': `Bearer ${user.token}`,
        },
      });

      const data = await response.json();
      if (data.success) {
        const otherUsersStories = data.data.stories.filter(
          userStories => userStories.author.id !== user.id
        );
        setStories(otherUsersStories);
      }
    } catch (error) {
      console.error('Error fetching stories:', error);
    }
  };

  // Fetch current user's stories
  const fetchMyStories = async () => {
    try {
      const response = await fetch(`${API_CONFIG.API_URL}/stories/user/${user.id}`, {
        headers: {
          'Authorization': `Bearer ${user.token}`,
        },
      });

      const data = await response.json();
      if (data.success) {
        return data.data.stories;
      }
      return [];
    } catch (error) {
      console.error('Error fetching my stories:', error);
      return [];
    }
  };

  // Create new story
  const createStory = async () => {
    try {
      if (storyType === 'text' && !newStoryContent.trim()) {
        alert('Please add some content to your story');
        return;
      }
      
      if (storyType === 'media' && !uploadedMedia) {
        alert('Please select a photo or video');
        return;
      }

      let storyData;
      
      if (storyType === 'media') {
        const formData = new FormData();
        formData.append('media', uploadedMedia);
        formData.append('content', newStoryContent);
        formData.append('mediaType', uploadedMedia.type.startsWith('image/') ? 'image' : 'video');
        
        const response = await fetch(`${API_CONFIG.API_URL}/stories/create`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${user.token}`,
          },
          body: formData,
        });
        
        const data = await response.json();
        if (data.success) {
          resetCreateStory();
          fetchStories();
          const myStoriesData = await fetchMyStories();
          setMyStories(myStoriesData);
          alert('Story created successfully!');
        } else {
          alert('Failed to create story: ' + data.message);
        }
        return;
      } else {
        storyData = {
          content: newStoryContent,
          media: '',
          mediaType: 'text',
          backgroundColor: selectedBackgroundColor,
          textColor: textColor,
          textSize: textSize
        };
      }

      const response = await fetch(`${API_CONFIG.API_URL}/stories/create`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${user.token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(storyData),
      });

      const data = await response.json();
      if (data.success) {
        resetCreateStory();
        fetchStories();
        const myStoriesData = await fetchMyStories();
        setMyStories(myStoriesData);
        alert('Story created successfully!');
      } else {
        alert('Failed to create story: ' + data.message);
      }
    } catch (error) {
      console.error('Error creating story:', error);
      alert('Error creating story');
    }
  };

  const resetCreateStory = () => {
    setNewStoryContent('');
    setUploadedMedia(null);
    setMediaPreview('');
    setSelectedBackgroundColor('#25D366');
    setTextColor('#ffffff');
    setTextSize('medium');
    setShowColorPicker(false);
    setShowTextStyling(false);
    setShowCreateStory(false);
  };

  // View story
  const viewStory = async (storyId) => {
    try {
      await fetch(`${API_CONFIG.API_URL}/stories/view/${storyId}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${user.token}`,
        },
      });
    } catch (error) {
      console.error('Error viewing story:', error);
    }
  };

  // Open story viewer
  const openStoryViewer = (userStories, index = 0) => {
    setSelectedUserStories(userStories);
    setCurrentStoryIndex(index);
    setShowStoryViewer(true);
    setShowComments(false);
    
    if (userStories.stories[index]) {
      viewStory(userStories.stories[index].id);
    }
  };

  // Navigate stories
  const nextStory = () => {
    setShowComments(false);
    
    if (selectedUserStories && currentStoryIndex < selectedUserStories.stories.length - 1) {
      const nextIndex = currentStoryIndex + 1;
      setCurrentStoryIndex(nextIndex);
      viewStory(selectedUserStories.stories[nextIndex].id);
    } else {
      if (selectedUserStories.author.id !== user.id) {
        const currentUserIndex = stories.findIndex(s => s.author.id === selectedUserStories.author.id);
        if (currentUserIndex < stories.length - 1) {
          const nextUser = stories[currentUserIndex + 1];
          openStoryViewer(nextUser, 0);
        } else {
          setShowStoryViewer(false);
        }
      } else {
        setShowStoryViewer(false);
      }
    }
  };

  const prevStory = () => {
    setShowComments(false);
    
    if (currentStoryIndex > 0) {
      setCurrentStoryIndex(currentStoryIndex - 1);
    } else {
      if (selectedUserStories.author.id !== user.id) {
        const currentUserIndex = stories.findIndex(s => s.author.id === selectedUserStories.author.id);
        if (currentUserIndex > 0) {
          const prevUser = stories[currentUserIndex - 1];
          openStoryViewer(prevUser, prevUser.stories.length - 1);
        }
      }
    }
  };

  // Handle file selection
  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      setUploadedMedia(file);
      const url = URL.createObjectURL(file);
      setMediaPreview(url);
    }
  };

  // Like/Unlike story
  const toggleLike = async (storyId) => {
    try {
      const response = await fetch(`${API_CONFIG.API_URL}/stories/${storyId}/like`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${user.token}`,
        },
      });

      const data = await response.json();
      if (data.success) {
        setStoryLikes(prev => ({
          ...prev,
          [storyId]: {
            count: data.data.likeCount,
            isLiked: data.data.isLiked
          }
        }));
      }
    } catch (error) {
      console.error('Error toggling like:', error);
    }
  };

  // Add comment to story
  const addComment = async (storyId, commentText) => {
    try {
      const response = await fetch(`${API_CONFIG.API_URL}/stories/${storyId}/comment`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${user.token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content: commentText }),
      });

      const data = await response.json();
      if (data.success) {
        setNewComment('');
        if (showComments) {
          fetchStoryComments(storyId);
        }
      }
    } catch (error) {
      console.error('Error adding comment:', error);
    }
  };

  // Fetch story comments
  const fetchStoryComments = async (storyId) => {
    try {
      const response = await fetch(`${API_CONFIG.API_URL}/stories/${storyId}/comments`, {
        headers: {
          'Authorization': `Bearer ${user.token}`,
        },
      });

      const data = await response.json();
      if (data.success) {
        setCurrentStoryComments(data.data.comments);
      }
    } catch (error) {
      console.error('Error fetching comments:', error);
    }
  };

  // Toggle comments
  const toggleComments = (storyId) => {
    if (!showComments) {
      fetchStoryComments(storyId);
    }
    setShowComments(!showComments);
  };

  // Fetch story viewers
  const fetchStoryViewers = async (storyId) => {
    try {
      const response = await fetch(`${API_CONFIG.API_URL}/stories/${storyId}/viewers`, {
        headers: {
          'Authorization': `Bearer ${user.token}`,
        },
      });

      const data = await response.json();
      if (data.success) {
        setStoryViewers(data.data.viewers);
        setShowViewers(true);
      }
    } catch (error) {
      console.error('Error fetching story viewers:', error);
    }
  };

  useEffect(() => {
    const loadStories = async () => {
      await fetchStories();
      const myStoriesData = await fetchMyStories();
      setMyStories(myStoriesData);
    };
    loadStories();
  }, []);

  // Story Viewers Modal
  if (showViewers) {
    return (
      <div className="whatsapp-story-viewers-modal">
        <div className="whatsapp-story-viewers-overlay" onClick={() => setShowViewers(false)}></div>
        <div className="whatsapp-story-viewers-content">
          <div className="whatsapp-story-viewers-header">
            <h3>Story Viewers</h3>
            <button 
              className="whatsapp-close-viewers-btn"
              onClick={() => setShowViewers(false)}
            >
              ✕
            </button>
          </div>
          
          <div className="whatsapp-viewers-list">
            {storyViewers.length > 0 ? (
              storyViewers.map((viewer) => (
                <div key={viewer.user._id} className="whatsapp-viewer-item">
                  <div className="whatsapp-viewer-avatar">
                    {viewer.user.avatar ? (
                      <img src={viewer.user.avatar} alt={viewer.user.name} />
                    ) : (
                      <div className="whatsapp-default-avatar">
                        {viewer.user.name.charAt(0).toUpperCase()}
                      </div>
                    )}
                  </div>
                  <div className="whatsapp-viewer-info">
                    <h4>{viewer.user.name}</h4>
                    <span>{new Date(viewer.viewedAt).toLocaleString()}</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="whatsapp-no-viewers">
                <p>No one has viewed this story yet</p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Story Viewer
  if (showStoryViewer && selectedUserStories) {
    const currentStory = selectedUserStories.stories[currentStoryIndex];
    const isMyStory = selectedUserStories.author.id === user.id;
    
    return (
      <div className="whatsapp-story-viewer" ref={storyViewerRef}>
        <div className="whatsapp-story-viewer-header">
          <div className="whatsapp-story-author-info">
            <div className="whatsapp-story-author-avatar">
              {selectedUserStories.author.avatar ? (
                <img src={selectedUserStories.author.avatar} alt={selectedUserStories.author.name} />
              ) : (
                <div className="whatsapp-default-avatar">
                  {selectedUserStories.author.name.charAt(0).toUpperCase()}
                </div>
              )}
            </div>
            <div className="whatsapp-story-author-details">
              <h4>{selectedUserStories.author.name}</h4>
              <span>{new Date(currentStory.createdAt).toLocaleTimeString()}</span>
            </div>
          </div>
          <div className="whatsapp-story-viewer-actions">
            {isMyStory && (
              <>
                <Tooltip title="View Story Viewers">
                  <Button 
                    icon={<EyeOutlined />}
                    onClick={() => fetchStoryViewers(currentStory.id)}
                  >
                    {currentStory.viewCount || 0}
                  </Button>
                      </Tooltip>
                <Tooltip title="Delete Story">
                  <Button 
                    danger
                    icon={<DeleteOutlined />}
                    onClick={() => {
                      if (window.confirm('Are you sure you want to delete this story?')) {
                        // deleteStory(currentStory.id);
                        setShowStoryViewer(false);
                      }
                    }}
                  />
                </Tooltip>
              </>
            )}
            <Tooltip title="Close">
              <Button icon={<CloseOutlined />} onClick={() => setShowStoryViewer(false)} />
            </Tooltip>
          </div>
        </div>

        <div className="whatsapp-story-progress">
          {selectedUserStories.stories.map((_, index) => (
            <div 
              key={index}
              className={`whatsapp-progress-bar ${index <= currentStoryIndex ? 'active' : ''}`}
            />
          ))}
        </div>

        <div className="whatsapp-story-content">
          {currentStory.mediaType === 'image' && currentStory.media && (
            <img 
              src={`${API_CONFIG.BASE_URL}${currentStory.media}`} 
              alt="Story media" 
              className="whatsapp-story-media"
            />
          )}
          {currentStory.mediaType === 'video' && currentStory.media && (
            <video 
              src={`${API_CONFIG.BASE_URL}${currentStory.media}`} 
              className="whatsapp-story-media"
              controls
              autoPlay
              muted
            />
          )}
          {currentStory.mediaType === 'text' && currentStory.content && (
            <div 
              className="whatsapp-story-text-overlay w-full h-full flex items-center justify-center text-center p-8"
              style={{
                backgroundColor: currentStory.backgroundColor || '#25D366',
                color: currentStory.textColor || '#ffffff',
                fontSize: currentStory.textSize === 'small' ? '1.2rem' : 
                         currentStory.textSize === 'large' ? '2rem' : '1.6rem',
                minHeight: '100vh',
                minWidth: '100vw'
              }}
            >
              <p className="w-full h-full flex items-center justify-center text-center break-words whitespace-pre-wrap">{currentStory.content}</p>
            </div>
          )}
          {currentStory.mediaType !== 'text' && currentStory.content && (
            <div className="whatsapp-story-caption-overlay">
              <p>{currentStory.content}</p>
            </div>
          )}
        </div>

        {!isMyStory && (
          <div className="whatsapp-story-interactions">
            <div className="whatsapp-story-interaction-buttons">
              <Space>
                <Button 
                  type={storyLikes[currentStory.id]?.isLiked ? 'primary' : 'default'}
                  icon={<HeartOutlined />}
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleLike(currentStory.id);
                  }}
                >
                  {storyLikes[currentStory.id]?.count || currentStory.likeCount || 0}
                </Button>
                <Button 
                  icon={<MessageOutlined />}
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleComments(currentStory.id);
                  }}
                >
                  {currentStory.commentCount || 0}
                </Button>
              </Space>
            </div>
          </div>
        )}

        {showComments && (
          <div className="whatsapp-story-comments-section">
            <div className="whatsapp-comments-header">
              <h4>Comments</h4>
              <button 
                className="whatsapp-close-comments-btn"
                onClick={() => setShowComments(false)}
              >
                ✕
              </button>
            </div>
            
            <div className="whatsapp-comments-list">
              {currentStoryComments.length > 0 ? (
                currentStoryComments.map((comment) => (
                  <div key={comment.id} className="whatsapp-comment-item">
                    <div className="whatsapp-comment-author-avatar">
                      {comment.author.avatar ? (
                        <img src={comment.author.avatar} alt={comment.author.name} />
                      ) : (
                        <div className="whatsapp-default-avatar">
                          {comment.author.name.charAt(0).toUpperCase()}
                        </div>
                      )}
                    </div>
                    <div className="whatsapp-comment-content">
                      <div className="whatsapp-comment-header">
                        <span className="whatsapp-comment-author-name">{comment.author.name}</span>
                        <span className="whatsapp-comment-time">
                          {new Date(comment.createdAt).toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="whatsapp-comment-text">{comment.content}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="whatsapp-no-comments">
                  <p>No comments yet. Be the first to comment!</p>
                </div>
              )}
            </div>
            
              <div className="whatsapp-add-comment-section">
                <div className="whatsapp-comment-input-container">
                  <Input
                    ref={commentInputRef}
                    placeholder="Add a comment..."
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    onPressEnter={() => {
                      if (newComment.trim()) {
                        addComment(currentStory.id, newComment.trim());
                      }
                    }}
                  />
                  <Button 
                    type="primary"
                    icon={<SendOutlined />}
                    onClick={() => {
                      if (newComment.trim()) {
                        addComment(currentStory.id, newComment.trim());
                      }
                    }}
                    disabled={!newComment.trim()}
                  />
                </div>
              </div>
          </div>
        )}

        <div className="whatsapp-story-navigation">
          <div className="whatsapp-nav-area left" onClick={prevStory} title="Previous story"></div>
          <div className="whatsapp-nav-area right" onClick={nextStory} title="Next story"></div>
        </div>
      </div>
    );
  }

  // Story Options Modal
  if (showStoryOptions) {
    return (
      <div className="whatsapp-story-options-modal">
        <div className="whatsapp-story-options-overlay" onClick={() => setShowStoryOptions(false)}></div>
        <div className="whatsapp-story-options-content">
          <div className="whatsapp-story-options-header">
            <h3>Create Story</h3>
            <button 
              className="whatsapp-close-options-btn"
              onClick={() => setShowStoryOptions(false)}
            >
              ✕
            </button>
          </div>
          
          <div className="whatsapp-story-options-buttons">
            <button 
              className="whatsapp-story-option-btn whatsapp-text-option"
              onClick={() => {
                setStoryType('text');
                setShowStoryOptions(false);
                setShowCreateStory(true);
              }}
            >
              <div className="whatsapp-option-icon">📝</div>
              <span>Text Story</span>
            </button>
            
            <button 
              className="whatsapp-story-option-btn whatsapp-media-option"
              onClick={() => {
                setStoryType('media');
                setShowStoryOptions(false);
                setShowCreateStory(true);
              }}
            >
              <div className="whatsapp-option-icon">📷</div>
              <span>Photo/Video</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Create Story Interface
  if (showCreateStory) {
    return (
      <div className="text-gray-800" style={{ backgroundColor: storyType === 'text' ? selectedBackgroundColor : '#ffffff' }}>
        <div className="flex justify-between items-center border-b border-gray-200 p-0 m-0" style={{ backgroundColor: storyType === 'text' ? selectedBackgroundColor : '#ffffff' }}>
          <Button 
            type="text" 
            className="text-blue-600 hover:bg-blue-100 hover:bg-opacity-50" 
            onClick={() => setShowCreateStory(false)}
          >
            ←
          </Button>
          <Title level={3} className="text-gray-800 mb-0">Create Story</Title>
          <div className="w-8"></div>
        </div>

        <div className="p-0 m-0" style={{ backgroundColor: storyType === 'text' ? selectedBackgroundColor : '#ffffff' }}>
          {storyType === 'text' ? (
            <>
              <Row gutter={[0, 0]} className="mb-0 p-0" style={{ backgroundColor: selectedBackgroundColor }}>
                <Col span={24} className="p-0">
                  <Card 
                    className="w-full h-full overflow-hidden flex-shrink-0 shadow-lg border-0"
                    bodyStyle={{ padding: 0, margin: 0, backgroundColor: selectedBackgroundColor }}
                  >
                    <div 
                      className="w-full flex items-center justify-center text-center box-border overflow-hidden relative"
                      style={{ 
                        backgroundColor: selectedBackgroundColor,
                        height: 'calc(100vh - 231px)',
                        minHeight: 'calc(100vh - 294px)',
                        width: '100%'
                      }}
                    >
                      {/* Floating style controls inside preview */}
                      <div className="absolute top-3 right-3 flex gap-2 z-20">
                        <Tooltip title="Background Colors">
                          <Button 
                            shape="circle"
                            size="large"
                            icon={<BgColorsOutlined />}
                            className="bg-gradient-to-r from-blue-500 to-purple-600 border-0 text-white hover:from-blue-600 hover:to-purple-700 shadow-lg"
                            onClick={() => setShowColorPicker(!showColorPicker)}
                          />
                        </Tooltip>
                        <Tooltip title="Text Styling">
                          <Button 
                            shape="circle"
                            size="large"
                            icon={<EditOutlined />}
                            className="bg-gradient-to-r from-green-500 to-teal-600 border-0 text-white hover:from-green-600 hover:to-teal-700 shadow-lg"
                            onClick={() => setShowTextStyling(!showTextStyling)}
                          />
                        </Tooltip>
                      </div>
                      {newStoryContent && (
                        <div 
                          className="font-medium leading-relaxed break-words whitespace-pre-wrap break-all overflow-wrap-break-word hyphens-auto text-center w-full h-full flex items-center justify-center p-4"
                          style={{ 
                            color: textColor,
                            fontSize: textSize === 'small' ? '1.2rem' : textSize === 'large' ? '2rem' : '1.6rem'
                          }}
                        >
                          {newStoryContent}
                        </div>
                      )}
                      {!newStoryContent && (
                        <div className="text-gray-500 text-xl italic w-full h-full flex items-center justify-center">
                          Type your story here...
                        </div>
                      )}
                      {/* In-preview composer like WhatsApp */}
                      <div className="absolute left-1/2 -translate-x-1/2 bottom-4 w-[92%] max-w-[520px]">
                        <div className="flex items-center gap-3 py-2">
                          <div className="flex-1">
                            <div className="flex items-center bg-white/95 backdrop-blur border border-gray-300 rounded-full px-3 py-2 shadow-sm focus-within:border-blue-400 focus-within:shadow-md transition-all duration-200">
                              <SmileOutlined className="text-gray-500 text-xl mr-2" />
                              <Input.TextArea
                                placeholder="Type a message"
                                value={newStoryContent}
                                onChange={(e) => setNewStoryContent(e.target.value)}
                                autoSize={{ minRows: 1, maxRows: 4 }}
                                className="bg-transparent border-0 text-gray-800 text-base resize-none p-0 m-0"
                                style={{ boxShadow: 'none' }}
                              />
                              <div className={`flex items-center gap-2 ml-2 transition-opacity duration-200 ${newStoryContent.trim() ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
                                <PaperClipOutlined className="text-gray-500 text-xl cursor-pointer" />
                                <CameraOutlined className="text-gray-500 text-xl cursor-pointer" />
                              </div>
                            </div>
                          </div>
                          <Button
                            type="primary"
                            shape="circle"
                            size="large"
                            icon={newStoryContent.trim() ? <SendOutlined /> : <AudioOutlined />}
                            className={`shadow-md ${newStoryContent.trim() ? 'bg-green-500 border-green-500 hover:bg-green-600' : 'bg-blue-500 border-blue-500 hover:bg-blue-600'}`}
                            onClick={createStory}
                            disabled={!newStoryContent.trim()}
                          />
                        </div>
                      </div>
                      {/* Inline compact pickers overlay at right */}
                      {(showColorPicker || showTextStyling) && (
                        <div className="absolute right-3 top-16 w-56 bg-white/95 backdrop-blur border border-gray-300 rounded-xl p-3 shadow-lg z-20 space-y-4">
                          {showColorPicker && (
                            <div>
                              <Title level={5} className="!m-0 !text-gray-800 text-sm">Background</Title>
                              <div className="mt-2">
                                <div 
                                  className="w-full h-6 rounded-full relative cursor-crosshair border border-gray-300 overflow-hidden"
                                  onClick={(e) => {
                                    const rect = e.currentTarget.getBoundingClientRect();
                                    const x = e.clientX - rect.left;
                                    const percentage = (x / rect.width) * 100;
                                    const hue = (percentage / 100) * 360;
                                    const hslColor = `hsl(${hue}, 100%, 50%)`;
                                    setSelectedBackgroundColor(hslColor);
                                  }}
                                >
                                  <div className="w-full h-full rounded-full bg-gradient-to-r from-red-500 via-yellow-500 via-green-500 via-cyan-500 via-blue-500 to-purple-500"></div>
                                  <div 
                                    className="absolute w-4 h-4 rounded-full border-2 border-white top-1/2 transform -translate-y-1/2 pointer-events-none shadow"
                                    style={{
                                      backgroundColor: selectedBackgroundColor,
                                      left: `${getColorPosition(selectedBackgroundColor)}%`
                                    }}
                                  ></div>
                                </div>
                              </div>
                            </div>
                          )}
                          {showTextStyling && (
                            <div>
                              <Title level={5} className="!m-0 !text-gray-800 text-sm">Text</Title>
                              <div className="mt-2">
                                <div 
                                  className="w-full h-6 rounded-full relative cursor-crosshair border border-gray-300 overflow-hidden"
                                  onClick={(e) => {
                                    const rect = e.currentTarget.getBoundingClientRect();
                                    const x = e.clientX - rect.left;
                                    const percentage = (x / rect.width) * 100;
                                    const hue = (percentage / 100) * 360;
                                    const hslColor = `hsl(${hue}, 100%, 50%)`;
                                    setTextColor(hslColor);
                                  }}
                                >
                                  <div className="w-full h-full rounded-full bg-gradient-to-r from-red-500 via-yellow-500 via-green-500 via-cyan-500 via-blue-500 to-purple-500"></div>
                                  <div 
                                    className="absolute w-4 h-4 rounded-full border-2 border-white top-1/2 transform -translate-y-1/2 pointer-events-none shadow"
                                    style={{
                                      backgroundColor: textColor,
                                      left: `${getColorPosition(textColor)}%`
                                    }}
                                  ></div>
                                </div>
                                <div className="mt-3 flex gap-2">
                                  <Button size="small" type={textSize==='small'?'primary':'default'} onClick={() => setTextSize('small')}>A</Button>
                                  <Button size="small" type={textSize==='medium'?'primary':'default'} onClick={() => setTextSize('medium')}>A</Button>
                                  <Button size="small" type={textSize==='large'?'primary':'default'} onClick={() => setTextSize('large')}>A</Button>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </Card>
                </Col>

                {/* End Row around preview */}
              </Row>

            </>
          ) : (
            <>
              <div className="whatsapp-media-upload-section" style={{ backgroundColor: '#ffffff' }}>
                <div className="whatsapp-media-upload-area" style={{ backgroundColor: '#ffffff' }}>
                  {mediaPreview ? (
                    <div className="whatsapp-media-preview-container">
                      {uploadedMedia?.type.startsWith('image/') ? (
                        <img src={mediaPreview} alt="Media preview" className="whatsapp-media-preview" />
                      ) : (
                        <video src={mediaPreview} controls className="whatsapp-media-preview" />
                      )}
                      <button 
                        className="whatsapp-remove-media-btn"
                        onClick={() => {
                          setUploadedMedia(null);
                          setMediaPreview('');
                          if (fileInputRef.current) {
                            fileInputRef.current.value = '';
                          }
                        }}
                      >
                        ✕
                      </button>
                    </div>
                  ) : (
                    <div 
                      className="whatsapp-media-upload-placeholder"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <div className="whatsapp-upload-icon">📷</div>
                      <p>Tap to add photo or video</p>
                      <span>Supports JPG, PNG, MP4</span>
                    </div>
                  )}
                </div>
                
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,video/*"
                  onChange={handleFileSelect}
                  style={{ display: 'none' }}
                />
              </div>

              <div className="relative" style={{ backgroundColor: '#ffffff' }}>
                <div className="flex items-center gap-3">
                  <div className="flex-1">
                    <div className="flex items-center bg-white border border-gray-300 rounded-full px-3 py-2 shadow-sm focus-within:border-blue-400 focus-within:shadow-md transition-all duration-200">
                      <SmileOutlined className="text-gray-500 text-xl mr-2" />
                      <Input.TextArea
                        placeholder="Add a caption..."
                        value={newStoryContent}
                        onChange={(e) => setNewStoryContent(e.target.value)}
                        autoSize={{ minRows: 1, maxRows: 4 }}
                        className="bg-transparent border-0 text-gray-800 text-base resize-none p-0 m-0"
                        style={{ boxShadow: 'none' }}
                      />
                      <div className={`flex items-center gap-2 ml-2 transition-opacity duration-200 ${newStoryContent.trim() ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
                        <PaperClipOutlined className="text-gray-500 text-xl cursor-pointer" />
                        <CameraOutlined className="text-gray-500 text-xl cursor-pointer" />
                      </div>
                    </div>
                  </div>
                  <Button
                    type="primary"
                    shape="circle"
                    size="large"
                    icon={(uploadedMedia || newStoryContent.trim()) ? <SendOutlined /> : <AudioOutlined />}
                    className={`shadow-md ${(uploadedMedia || newStoryContent.trim()) ? 'bg-green-500 border-green-500 hover:bg-green-600' : 'bg-blue-500 border-blue-500 hover:bg-blue-600'}`}
                    onClick={createStory}
                    disabled={!uploadedMedia && !newStoryContent.trim()}
                  />
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white min-h-screen text-gray-800 font-sans">
      {/* WhatsApp-style Story Viewer */}
      {showStoryViewer && selectedUserStories && (
        <div className="fixed inset-0 z-50 bg-black">
          <div className="relative w-full h-full">
            {/* Story Content */}
            <div className="absolute inset-0">
              {selectedUserStories.stories[currentStoryIndex] ? (
                <div className="w-full h-full flex items-center justify-center">
                  {selectedUserStories.stories[currentStoryIndex].type === 'text' ? (
                    <div 
                      className="w-full h-full flex items-center justify-center text-center p-8"
                      style={{ 
                        backgroundColor: selectedUserStories.stories[currentStoryIndex].backgroundColor || '#25D366',
                        color: selectedUserStories.stories[currentStoryIndex].textColor || '#ffffff'
                      }}
                    >
                      <div 
                        className="text-4xl font-medium leading-relaxed"
                        style={{ 
                          fontSize: selectedUserStories.stories[currentStoryIndex].textSize === 'small' ? '2rem' : 
                                   selectedUserStories.stories[currentStoryIndex].textSize === 'large' ? '4rem' : '3rem'
                        }}
                      >
                        {selectedUserStories.stories[currentStoryIndex].content}
                      </div>
                    </div>
                  ) : (
                    <div className="w-full h-full">
                      {selectedUserStories.stories[currentStoryIndex].mediaType === 'image' ? (
                        <img 
                          src={`${API_CONFIG.BASE_URL}${selectedUserStories.stories[currentStoryIndex].media}`}
                          alt="Story"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <video 
                          src={`${API_CONFIG.BASE_URL}${selectedUserStories.stories[currentStoryIndex].media}`}
                          className="w-full h-full object-cover"
                          autoPlay
                          muted
                          loop
                        />
                      )}
                      {selectedUserStories.stories[currentStoryIndex].content && (
                        <div className="absolute bottom-20 left-4 right-4">
                          <div className="bg-black bg-opacity-50 text-white p-4 rounded-lg">
                            <Text className="text-white text-lg">{selectedUserStories.stories[currentStoryIndex].content}</Text>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ) : null}
            </div>

            {/* Header */}
            <div className="absolute top-0 left-0 right-0 z-10 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Avatar 
                    size={40}
                    src={selectedUserStories.author.avatar}
                    className="border-2 border-white"
                  >
                    {selectedUserStories.author.name.charAt(0).toUpperCase()}
                  </Avatar>
                  <div>
                    <Text className="text-white font-medium">{selectedUserStories.author.name}</Text>
                    <div className="text-white text-xs opacity-75">
                      {new Date(selectedUserStories.stories[currentStoryIndex]?.createdAt).toLocaleTimeString()}
                    </div>
                  </div>
                </div>
                <Button 
                  type="text"
                  icon={<CloseOutlined />}
                  className="text-white hover:bg-white hover:bg-opacity-20"
                  onClick={() => setShowStoryViewer(false)}
                />
              </div>
            </div>

            {/* Progress Bars */}
            <div className="absolute top-16 left-4 right-4 z-10">
              <div className="flex space-x-1">
                {selectedUserStories.stories.map((_, index) => (
                  <div 
                    key={index}
                    className={`h-1 flex-1 rounded-full ${
                      index < currentStoryIndex ? 'bg-white' : 
                      index === currentStoryIndex ? 'bg-white bg-opacity-50' : 'bg-white bg-opacity-30'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Navigation */}
            <div className="absolute inset-0 flex">
              <div 
                className="flex-1 cursor-pointer"
                onClick={() => {
                  if (currentStoryIndex > 0) {
                    setCurrentStoryIndex(currentStoryIndex - 1);
                  }
                }}
              />
              <div 
                className="flex-1 cursor-pointer"
                onClick={() => {
                  if (currentStoryIndex < selectedUserStories.stories.length - 1) {
                    setCurrentStoryIndex(currentStoryIndex + 1);
                  } else {
                    setShowStoryViewer(false);
                  }
                }}
              />
            </div>

            {/* Bottom Actions */}
            <div className="absolute bottom-0 left-0 right-0 z-10 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Button 
                    type="text"
                    icon={<HeartOutlined />}
                    className="text-white hover:bg-white hover:bg-opacity-20"
                    onClick={() => likeStory(selectedUserStories.stories[currentStoryIndex]._id)}
                  />
                  <Button 
                    type="text"
                    icon={<MessageOutlined />}
                    className="text-white hover:bg-white hover:bg-opacity-20"
                    onClick={() => setShowComments(!showComments)}
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Button 
                    type="text"
                    icon={<SendOutlined />}
                    className="text-white hover:bg-white hover:bg-opacity-20"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="p-5 max-w-6xl mx-auto">
        {stories.length === 0 && myStories.length === 0 ? (
          <Card className="text-center bg-gradient-to-br from-blue-50 to-indigo-100 border-blue-200 shadow-lg">
            <div className="text-6xl mb-5">📸</div>
            <Title level={3} className="text-gray-800 mb-2">No Stories Yet</Title>
            <Text className="text-gray-600 mb-8 block">Share your moments with friends!</Text>
            <Button 
              type="primary"
              size="large"
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 border-0 shadow-lg"
              onClick={() => setShowCreateStory(true)}
            >
              Create Your First Story
            </Button>
          </Card>
        ) : (
          <div className="space-y-3">
            {/* My Story */}
            <Card 
              className="bg-white border-gray-200 shadow-md hover:shadow-lg cursor-pointer transition-all duration-300"
              bodyStyle={{ padding: '16px' }}
              onClick={(e) => {
                // If click originated from add-story dropdown trigger, do nothing
                const target = e.target;
                if (target && typeof target.closest === 'function' && target.closest('.add-story-trigger')) {
                  return;
                }
                if (myStories.length > 0) {
                  const myStoryData = {
                    author: {
                      id: user.id,
                      name: user.name,
                      avatar: user.avatar
                    },
                    stories: myStories,
                    hasUnviewedStories: false
                  };
                  openStoryViewer(myStoryData);
                } else {
                  setShowCreateStory(true);
                }
              }}
              >
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <div className="relative">
                      <div 
                        className={`w-16 h-16 rounded-full border-3 flex items-center justify-center ${
                          myStories.length > 0 ? 'border-green-500' : 'border-gray-400'
                        }`}
                        style={{ 
                          background: myStories.length > 0 
                            ? 'linear-gradient(45deg, #00a884, #25d366, #128c7e)' 
                            : '#e5e7eb'
                        }}
                      >
                        <div className="w-14 h-14 rounded-full overflow-hidden bg-white">
                          {myStories.length > 0 ? (
                            myStories[0].mediaType === 'text' ? (
                              <div 
                                className="w-full h-full flex items-center justify-center text-center p-1"
                                style={{ 
                                  backgroundColor: myStories[0].backgroundColor || '#25D366',
                                  color: myStories[0].textColor || '#ffffff'
                                }}
                              >
                                <div 
                                  className="text-xs font-medium leading-tight"
                                  style={{ 
                                    color: myStories[0].textColor || '#ffffff',
                                    fontSize: myStories[0].textSize === 'small' ? '0.6rem' : 
                                             myStories[0].textSize === 'large' ? '0.8rem' : '0.7rem'
                                  }}
                                >
                                  {myStories[0].content}
                                </div>
                              </div>
                            ) : (
                              <div className="relative w-full h-full">
                                {myStories[0].mediaType === 'image' ? (
                                  <img 
                                    src={`${API_CONFIG.BASE_URL}${myStories[0].media}`}
                                    alt="Story preview"
                                    className="w-full h-full object-cover"
                                  />
                                ) : (
                                  <video 
                                    src={`${API_CONFIG.BASE_URL}${myStories[0].media}`}
                                    className="w-full h-full object-cover"
                                    muted
                                  />
                                )}
                                <div className="absolute bottom-0.5 right-0.5 bg-black bg-opacity-70 rounded-full w-3 h-3 flex items-center justify-center text-xs">
                                  {myStories[0].mediaType === 'image' ? <CameraOutlined /> : <VideoCameraOutlined />}
                                </div>
                              </div>
                            )
                          ) : (
                            user.avatar ? (
                              <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
                            ) : (
                              <div className="w-full h-full bg-gray-500 flex items-center justify-center text-white font-medium text-lg">
                                {user.name?.charAt(0)?.toUpperCase() || 'U'}
                              </div>
                            )
                          )}
                        </div>
                      </div>
                      <Dropdown
                        trigger={["click"]}
                        placement="bottomRight"
                        menu={{
                          onClick: (info) => {
                            if (info && info.domEvent && typeof info.domEvent.stopPropagation === 'function') {
                              info.domEvent.stopPropagation();
                            }
                          },
                          items: [
                            {
                              key: 'text',
                              label: 'Text Story',
                              onClick: (info) => {
                                setStoryType('text');
                                setShowStoryOptions(false);
                                setShowCreateStory(true);
                              }
                            },
                            {
                              key: 'media',
                              label: 'Photo/Video',
                              onClick: (info) => {
                                setStoryType('media');
                                setShowStoryOptions(false);
                                setShowCreateStory(true);
                              }
                            }
                          ]
                        }}
                      >
                        <Tooltip title="Add Story">
                          <Button 
                            type="primary"
                            shape="circle"
                            size="small"
                            icon={<PlusOutlined />}
                            className="add-story-trigger absolute -bottom-1 -right-1 bg-green-500 border-green-500 hover:bg-green-600 w-6 h-6 min-w-6"
                            onClick={(e) => {
                              e.stopPropagation();
                            }}
                            onMouseDown={(e) => {
                              e.stopPropagation();
                            }}
                            onClickCapture={(e) => {
                              e.stopPropagation();
                            }}
                          />
                        </Tooltip>
                      </Dropdown>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div>
                        <Text className="text-base font-medium text-gray-800 block">
                          {myStories.length > 0 
                            ? `${myStories.length} story${myStories.length > 1 ? 'ies' : ''}`
                            : 'Add your first story'
                          }
                        </Text>
                        <Text className="text-sm text-gray-500">
                          {myStories.length > 0 
                            ? 'Tap to view your stories'
                            : 'Share your moments'
                          }
                        </Text>
                      </div>
                      <div className="text-right">
                        <Text className="text-xs text-gray-400">
                          {myStories.length > 0 
                            ? new Date(myStories[0].createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})
                            : ''
                          }
                        </Text>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

            {/* Friend Story section label */}
            

            {/* Friends' Stories label */}
            {stories.length > 0 && (
              <div className="px-1 pt-2">
                <Text className="text-xs font-semibold uppercase tracking-wide text-gray-500">Friends' Stories</Text>
              </div>
            )}

            {/* Other users' stories */}
            {stories.map((userStories) => (
              <Card 
                key={userStories.author.id}
                className="bg-white border-gray-200 shadow-md hover:shadow-lg cursor-pointer transition-all duration-300"
                bodyStyle={{ padding: '16px' }}
                onClick={() => openStoryViewer(userStories)}
              >
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <div 
                      className={`w-16 h-16 rounded-full border-3 flex items-center justify-center ${
                        userStories.hasUnviewedStories ? 'border-green-500 animate-pulse' : 'border-gray-400'
                      }`}
                      style={{ 
                        background: userStories.hasUnviewedStories 
                          ? 'linear-gradient(45deg, #00a884, #25d366, #128c7e)' 
                          : '#e5e7eb'
                      }}
                    >
                      <div className="w-14 h-14 rounded-full overflow-hidden bg-white">
                        {userStories.stories[0].mediaType === 'text' ? (
                          <div 
                            className="w-full h-full flex items-center justify-center text-center p-1"
                            style={{ 
                              backgroundColor: userStories.stories[0].backgroundColor || '#25D366',
                              color: userStories.stories[0].textColor || '#ffffff'
                            }}
                          >
                            <div 
                              className="text-xs font-medium leading-tight"
                              style={{ 
                                color: userStories.stories[0].textColor || '#ffffff',
                                fontSize: userStories.stories[0].textSize === 'small' ? '0.6rem' : 
                                         userStories.stories[0].textSize === 'large' ? '0.8rem' : '0.7rem'
                              }}
                            >
                              {userStories.stories[0].content}
                            </div>
                          </div>
                        ) : (
                          <div className="relative w-full h-full">
                            {userStories.stories[0].mediaType === 'image' ? (
                              <img 
                                src={`${API_CONFIG.BASE_URL}${userStories.stories[0].media}`}
                                alt="Story preview"
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <video 
                                src={`${API_CONFIG.BASE_URL}${userStories.stories[0].media}`}
                                className="w-full h-full object-cover"
                                muted
                              />
                            )}
                            <div className="absolute bottom-0.5 right-0.5 bg-black bg-opacity-70 rounded-full w-3 h-3 flex items-center justify-center text-xs">
                              {userStories.stories[0].mediaType === 'image' ? <CameraOutlined /> : <VideoCameraOutlined />}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div>
                        <Text className="text-base font-medium text-gray-800 block">{userStories.author.name}</Text>
                        <Text className="text-sm text-gray-500">
                          {userStories.stories.length} story{userStories.stories.length > 1 ? 'ies' : ''}
                        </Text>
                      </div>
                      <div className="text-right">
                        <Text className="text-xs text-gray-400">
                          {new Date(userStories.stories[0].createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </Text>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default WhatsAppStory;
