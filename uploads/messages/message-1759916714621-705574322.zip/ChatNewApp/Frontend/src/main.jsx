import React from 'react'
import 'antd/dist/reset.css'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import { initializeMobileApp } from './utils/mobileInit'
import { register as registerSW } from './utils/serviceWorkerRegistration'
import { autoTestNotifications } from './utils/testNotification'
import { autoDebugNotifications } from './utils/notificationDebug'
import { debugAndroidApp } from './utils/androidDebug'

// Initialize mobile app if running on mobile
initializeMobileApp();

// Register service worker for notifications
registerSW({
  onSuccess: () => {
    console.log('📱 Service Worker registered successfully for notifications');
    // Auto-debug and test notifications in development
    if (import.meta.env.DEV) {
      autoDebugNotifications();
      autoTestNotifications();
    }
  },
  onUpdate: () => {
    console.log('📱 Service Worker updated - new content available');
  }
});

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)