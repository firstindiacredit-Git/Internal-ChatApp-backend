/**
 * Android Native Notification Service
 * Handles native Android notifications using Capacitor
 */

import { PushNotifications } from "@capacitor/push-notifications";
import { LocalNotifications } from "@capacitor/local-notifications";
import { Capacitor } from "@capacitor/core";
import { API_CONFIG } from "../config/mobileConfig";

class AndroidNotificationService {
  constructor() {
    this.isNative = Capacitor.isNativePlatform();
    this.isAndroid = Capacitor.getPlatform() === "android";
    this.fcmToken = null;
    this.isInitialized = false;
  }

  /**
   * Initialize notification service
   */
  async initialize() {
    if (this.isInitialized) return true;

    try {
      console.log("📱 Initializing Android notification service...");

      if (!this.isNative) {
        console.log("📱 Not running on native platform");
        return false;
      }

      // Request permissions
      const permissionResult = await this.requestPermissions();
      if (!permissionResult) {
        console.error("📱 Notification permissions denied");
        return false;
      }

      // Setup push notifications
      await this.setupPushNotifications();

      // Setup local notifications
      await this.setupLocalNotifications();

      this.isInitialized = true;
      console.log("📱 Android notification service initialized successfully");
      return true;
    } catch (error) {
      console.error(
        "📱 Error initializing Android notification service:",
        error
      );
      return false;
    }
  }

  /**
   * Request notification permissions
   */
  async requestPermissions() {
    try {
      // Request push notification permissions
      const pushPermission = await PushNotifications.requestPermissions();
      console.log("📱 Push notification permission:", pushPermission.receive);

      // Request local notification permissions
      const localPermission = await LocalNotifications.requestPermissions();
      console.log("📱 Local notification permission:", localPermission.display);

      return (
        pushPermission.receive === "granted" &&
        localPermission.display === "granted"
      );
    } catch (error) {
      console.error("📱 Error requesting permissions:", error);
      return false;
    }
  }

  /**
   * Setup push notifications (FCM)
   */
  async setupPushNotifications() {
    try {
      // Register for push notifications
      await PushNotifications.register();

      // Listen for registration
      PushNotifications.addListener("registration", async (token) => {
        console.log("📱 FCM Token received:", token.value);
        this.fcmToken = token.value;

        // Send FCM token to backend
        await this.sendTokenToBackend(token.value);
      });

      // Listen for registration errors
      PushNotifications.addListener("registrationError", (error) => {
        console.error("📱 FCM Registration error:", error);
      });

      // Listen for incoming push notifications
      PushNotifications.addListener(
        "pushNotificationReceived",
        (notification) => {
          console.log("📱 Push notification received:", notification);

          // Show local notification if app is in foreground
          this.showLocalNotification(
            notification.title || "New Message",
            notification.body || "You have a new message",
            notification.data || {}
          );
        }
      );

      // Listen for notification actions
      PushNotifications.addListener(
        "pushNotificationActionPerformed",
        (action) => {
          console.log("📱 Push notification action performed:", action);

          // Handle notification click
          this.handleNotificationClick(action.notification.data);
        }
      );

      console.log("📱 Push notifications setup completed");
    } catch (error) {
      console.error("📱 Error setting up push notifications:", error);
    }
  }

  /**
   * Setup local notifications
   */
  async setupLocalNotifications() {
    try {
      // Listen for local notification actions
      LocalNotifications.addListener(
        "localNotificationActionPerformed",
        (action) => {
          console.log("📱 Local notification action performed:", action);
          this.handleNotificationClick(action.notification.extra);
        }
      );

      console.log("📱 Local notifications setup completed");
    } catch (error) {
      console.error("📱 Error setting up local notifications:", error);
    }
  }

  /**
   * Send FCM token to backend
   */
  async sendTokenToBackend(token) {
    try {
      const authToken = this.getAuthToken();
      if (!authToken) {
        console.error("📱 No auth token found");
        return false;
      }

      const response = await fetch(
        `${API_CONFIG.API_URL}/notifications/fcm-subscribe`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${authToken}`,
          },
          body: JSON.stringify({
            fcmToken: token,
            platform: "android",
          }),
        }
      );

      const data = await response.json();

      if (data.success) {
        console.log("📱 FCM token sent to backend successfully");
        return true;
      } else {
        console.error("📱 Failed to send FCM token to backend:", data.message);
        return false;
      }
    } catch (error) {
      console.error("📱 Error sending FCM token to backend:", error);
      return false;
    }
  }

  /**
   * Show local notification
   */
  async showLocalNotification(title, body, data = {}) {
    try {
      await LocalNotifications.schedule({
        notifications: [
          {
            title: title,
            body: body,
            id: Date.now(),
            schedule: { at: new Date(Date.now() + 100) }, // Show immediately
            sound: "default",
            attachments: [],
            actionTypeId: "OPEN_CHAT",
            extra: data,
          },
        ],
      });

      console.log("📱 Local notification scheduled");
    } catch (error) {
      console.error("📱 Error showing local notification:", error);
    }
  }

  /**
   * Show message notification
   */
  async showMessageNotification(senderName, message, chatId) {
    const data = {
      type: "message",
      chatId: chatId,
      senderName: senderName,
    };

    if (this.isNative) {
      await this.showLocalNotification(senderName, message, data);
    }
  }

  /**
   * Show call notification
   */
  async showCallNotification(callerName, callType = "voice") {
    const data = {
      type: "call",
      callerName: callerName,
      callType: callType,
    };

    if (this.isNative) {
      await this.showLocalNotification(
        `Incoming ${callType} call`,
        `${callerName} is calling you`,
        data
      );
    }
  }

  /**
   * Show system notification
   */
  async showSystemNotification(title, message, type = "info") {
    const data = {
      type: "system",
      category: type,
      message: message,
    };

    if (this.isNative) {
      await this.showLocalNotification(title, message, data);
    }
  }

  /**
   * Handle notification click
   */
  handleNotificationClick(data) {
    console.log("📱 Notification clicked with data:", data);

    // Dispatch custom event to main app
    const event = new CustomEvent("androidNotificationClick", {
      detail: data,
    });
    window.dispatchEvent(event);
  }

  /**
   * Get authentication token
   */
  getAuthToken() {
    return (
      localStorage.getItem("token") ||
      localStorage.getItem("authToken") ||
      sessionStorage.getItem("token") ||
      sessionStorage.getItem("authToken")
    );
  }

  /**
   * Check if service is available
   */
  isAvailable() {
    return this.isNative && this.isAndroid;
  }

  /**
   * Get FCM token
   */
  getFCMToken() {
    return this.fcmToken;
  }

  /**
   * Clear all notifications
   */
  async clearAllNotifications() {
    try {
      if (this.isNative) {
        await LocalNotifications.cancel({
          notifications: [],
        });
      }
    } catch (error) {
      console.error("📱 Error clearing notifications:", error);
    }
  }
}

// Create singleton instance
const androidNotificationService = new AndroidNotificationService();

export default androidNotificationService;
