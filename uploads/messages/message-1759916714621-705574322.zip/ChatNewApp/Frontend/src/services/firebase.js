import { initializeApp, getApps, getApp } from "firebase/app";

// Read from Vite env (do not hardcode secrets)
const cfg = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

export function getFirebaseApp() {
  // Only initialize once
  if (getApps().length) return getApp();

  // Validate minimal required fields
  if (!cfg.apiKey || !cfg.projectId || !cfg.appId) {
    console.warn("Firebase not configured. Skipping initialization.");
    return null;
  }

  try {
    const app = initializeApp(cfg);
    console.log("✅ Firebase initialized");
    return app;
  } catch (e) {
    console.error("❌ Firebase initialization failed:", e);
    return null;
  }
}

export default getFirebaseApp;
