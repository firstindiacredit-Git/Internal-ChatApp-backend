/**
 * Simple Android Notification Service
 * Uses only local notifications without FCM for immediate APK testing
 */

import { LocalNotifications } from "@capacitor/local-notifications";
import { Capacitor } from "@capacitor/core";

class SimpleAndroidNotifications {
  constructor() {
    this.isNative = Capacitor.isNativePlatform();
    this.isAndroid = Capacitor.getPlatform() === "android";
    this.isInitialized = false;
  }

  /**
   * Initialize notification service
   */
  async initialize() {
    if (this.isInitialized) return true;

    try {
      console.log("📱 Initializing simple Android notifications...");

      if (!this.isNative) {
        console.log("📱 Not running on native platform");
        return false;
      }

      // Request local notification permissions
      const permission = await LocalNotifications.requestPermissions();
      console.log("📱 Local notification permission:", permission.display);

      if (permission.display !== "granted") {
        console.error("📱 Local notification permission denied");
        return false;
      }

      // Setup local notification listeners
      await this.setupLocalNotifications();

      this.isInitialized = true;
      console.log("📱 Simple Android notifications initialized successfully");
      return true;
    } catch (error) {
      console.error(
        "📱 Error initializing simple Android notifications:",
        error
      );
      return false;
    }
  }

  /**
   * Setup local notification listeners
   */
  async setupLocalNotifications() {
    try {
      // Listen for notification actions
      LocalNotifications.addListener(
        "localNotificationActionPerformed",
        (action) => {
          console.log("📱 Local notification clicked:", action);

          // Handle notification click
          this.handleNotificationClick(action.notification.extra);
        }
      );

      console.log("📱 Local notification listeners setup completed");
    } catch (error) {
      console.error("📱 Error setting up local notification listeners:", error);
    }
  }

  /**
   * Show local notification
   */
  async showLocalNotification(title, body, data = {}) {
    try {
      if (!this.isNative) {
        console.log("📱 Not on native platform - skipping notification");
        return;
      }

      const notificationId = Date.now();

      await LocalNotifications.schedule({
        notifications: [
          {
            title: title,
            body: body,
            id: notificationId,
            schedule: { at: new Date(Date.now() + 1000) }, // Show after 1 second
            sound: "default",
            attachments: [],
            actionTypeId: "OPEN_CHAT",
            extra: {
              ...data,
              notificationId: notificationId,
            },
            smallIcon: "ic_stat_icon_config_sample",
            iconColor: "#25D366",
          },
        ],
      });

      console.log("📱 Local notification scheduled:", title, body);
    } catch (error) {
      console.error("📱 Error showing local notification:", error);
    }
  }

  /**
   * Show message notification
   */
  async showMessageNotification(senderName, message, chatId) {
    const data = {
      type: "message",
      chatId: chatId,
      senderName: senderName,
    };

    await this.showLocalNotification(senderName, message, data);
  }

  /**
   * Show call notification
   */
  async showCallNotification(callerName, callType = "voice") {
    const data = {
      type: "call",
      callerName: callerName,
      callType: callType,
    };

    await this.showLocalNotification(
      `📞 Incoming ${callType} call`,
      `${callerName} is calling you`,
      data
    );
  }

  /**
   * Show system notification
   */
  async showSystemNotification(title, message, type = "info") {
    const data = {
      type: "system",
      category: type,
      message: message,
    };

    await this.showLocalNotification(title, message, data);
  }

  /**
   * Handle notification click
   */
  handleNotificationClick(data) {
    console.log("📱 Simple notification clicked with data:", data);

    // Dispatch custom event to main app
    const event = new CustomEvent("androidNotificationClick", {
      detail: data,
    });
    window.dispatchEvent(event);
  }

  /**
   * Check if service is available
   */
  isAvailable() {
    return this.isNative && this.isAndroid && this.isInitialized;
  }

  /**
   * Clear all notifications
   */
  async clearAllNotifications() {
    try {
      if (this.isNative) {
        // Get all pending notifications and cancel them
        const pending = await LocalNotifications.getPending();
        if (pending.notifications.length > 0) {
          const ids = pending.notifications.map((n) => n.id);
          await LocalNotifications.cancel({ notifications: ids });
        }
      }
    } catch (error) {
      console.error("📱 Error clearing notifications:", error);
    }
  }

  /**
   * Test notification
   */
  async testNotification() {
    try {
      await this.showLocalNotification(
        "Test Notification",
        "This is a test notification from ChatApp!",
        { type: "test" }
      );
      console.log("📱 Test notification sent");
    } catch (error) {
      console.error("📱 Error sending test notification:", error);
    }
  }
}

// Create singleton instance
const simpleAndroidNotifications = new SimpleAndroidNotifications();

export default simpleAndroidNotifications;
