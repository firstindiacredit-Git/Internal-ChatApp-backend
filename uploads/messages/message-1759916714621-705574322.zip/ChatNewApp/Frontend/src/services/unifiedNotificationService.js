/**
 * Unified Notification Service
 * Automatically detects platform and uses appropriate notification service
 */

import { Capacitor } from "@capacitor/core";
import webNotificationService from "./notificationService";
import simpleAndroidNotifications from "./simpleAndroidNotifications";

class UnifiedNotificationService {
  constructor() {
    this.isNative = Capacitor.isNativePlatform();
    this.platform = Capacitor.getPlatform();
    this.activeService = null;

    // Select appropriate service based on platform
    if (this.isNative && this.platform === "android") {
      this.activeService = simpleAndroidNotifications;
      console.log("📱 Using simple Android native notifications");
    } else {
      this.activeService = webNotificationService;
      console.log("📱 Using web notifications");
    }
  }

  /**
   * Initialize notification service
   */
  async initialize() {
    try {
      if (this.isNative && this.platform === "android") {
        return await simpleAndroidNotifications.initialize();
      } else {
        return await webNotificationService.requestPermission();
      }
    } catch (error) {
      console.error("📱 Error initializing notification service:", error);
      return false;
    }
  }

  /**
   * Request notification permission
   */
  async requestPermission() {
    return await this.initialize();
  }

  /**
   * Show message notification
   */
  async showMessageNotification(senderName, message, chatId) {
    try {
      if (this.activeService) {
        return await this.activeService.showMessageNotification(
          senderName,
          message,
          chatId
        );
      }
    } catch (error) {
      console.error("📱 Error showing message notification:", error);
    }
  }

  /**
   * Show call notification
   */
  async showCallNotification(callerName, callType = "voice") {
    try {
      if (this.activeService) {
        return await this.activeService.showCallNotification(
          callerName,
          callType
        );
      }
    } catch (error) {
      console.error("📱 Error showing call notification:", error);
    }
  }

  /**
   * Show system notification
   */
  async showSystemNotification(title, message, type = "info") {
    try {
      if (this.activeService) {
        return await this.activeService.showSystemNotification(
          title,
          message,
          type
        );
      }
    } catch (error) {
      console.error("📱 Error showing system notification:", error);
    }
  }

  /**
   * Check if notifications are enabled
   */
  isEnabled() {
    if (this.isNative && this.platform === "android") {
      return simpleAndroidNotifications.isAvailable();
    } else {
      return webNotificationService.isEnabled();
    }
  }

  /**
   * Get platform info
   */
  getPlatformInfo() {
    return {
      isNative: this.isNative,
      platform: this.platform,
      serviceType: this.isNative ? "native" : "web",
      isEnabled: this.isEnabled(),
    };
  }

  /**
   * Clear all notifications
   */
  async clearAllNotifications() {
    try {
      if (this.activeService && this.activeService.clearAllNotifications) {
        await this.activeService.clearAllNotifications();
      }
    } catch (error) {
      console.error("📱 Error clearing notifications:", error);
    }
  }
}

// Create singleton instance
const unifiedNotificationService = new UnifiedNotificationService();

export default unifiedNotificationService;
