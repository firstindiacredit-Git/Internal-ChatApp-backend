/**
 * Android Debug Utility
 * For debugging Android app issues
 */

import { Capacitor } from "@capacitor/core";
import { LocalNotifications } from "@capacitor/local-notifications";

export const debugAndroidApp = async () => {
  console.log("🔍 Debugging Android App...\n");

  // Platform Detection
  console.log("1. Platform Detection:");
  console.log("  Is Native Platform:", Capacitor.isNativePlatform());
  console.log("  Platform:", Capacitor.getPlatform());
  console.log("  App Info:", await Capacitor.getInfo());

  // Capacitor Plugins
  console.log("\n2. Capacitor Plugins:");
  try {
    const plugins = await Capacitor.getPlugins();
    console.log("  Available Plugins:", plugins);
  } catch (error) {
    console.log("  Plugin check error:", error.message);
  }

  // Local Notifications
  console.log("\n3. Local Notifications:");
  try {
    const permission = await LocalNotifications.checkPermissions();
    console.log("  Permission Status:", permission);

    if (permission.display === "granted") {
      console.log("  ✅ Local notifications permission granted");

      // Test notification
      try {
        await LocalNotifications.schedule({
          notifications: [
            {
              title: "Android Debug Test",
              body: "Local notifications are working!",
              id: Date.now(),
              schedule: { at: new Date(Date.now() + 2000) },
              sound: "default",
            },
          ],
        });
        console.log("  ✅ Test notification scheduled");
      } catch (error) {
        console.log("  ❌ Test notification failed:", error.message);
      }
    } else {
      console.log("  ❌ Local notifications permission not granted");
    }
  } catch (error) {
    console.log("  ❌ Local notifications error:", error.message);
  }

  // Network Status
  console.log("\n4. Network Status:");
  try {
    const { Network } = await import("@capacitor/network");
    const status = await Network.getStatus();
    console.log("  Network Connected:", status.connected);
    console.log("  Connection Type:", status.connectionType);
  } catch (error) {
    console.log("  Network check error:", error.message);
  }

  // Device Info
  console.log("\n5. Device Info:");
  try {
    const { Device } = await import("@capacitor/device");
    const info = await Device.getInfo();
    console.log("  Device Model:", info.model);
    console.log("  Platform:", info.platform);
    console.log("  OS Version:", info.osVersion);
    console.log("  App Version:", info.appVersion);
  } catch (error) {
    console.log("  Device info error:", error.message);
  }

  console.log("\n🔍 Android Debug Complete!");
};

// Test notification function
export const testAndroidNotification = async () => {
  try {
    console.log("📱 Testing Android notification...");

    if (!Capacitor.isNativePlatform()) {
      console.log("📱 Not on native platform - cannot test");
      return;
    }

    const permission = await LocalNotifications.requestPermissions();
    if (permission.display !== "granted") {
      console.log("📱 Permission denied");
      return;
    }

    await LocalNotifications.schedule({
      notifications: [
        {
          title: "ChatApp Test",
          body: "Android notifications are working! 🎉",
          id: Date.now(),
          schedule: { at: new Date(Date.now() + 1000) },
          sound: "default",
          smallIcon: "ic_stat_icon_config_sample",
          iconColor: "#25D366",
        },
      ],
    });

    console.log("📱 Test notification sent!");
  } catch (error) {
    console.error("📱 Test notification error:", error);
  }
};

// Make functions globally available
if (typeof window !== "undefined") {
  window.debugAndroidApp = debugAndroidApp;
  window.testAndroidNotification = testAndroidNotification;
}
