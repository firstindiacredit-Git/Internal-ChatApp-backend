/**
 * Notification Debug Utility
 * For debugging notification issues
 */

import { API_CONFIG } from "../config/mobileConfig";

export const debugNotifications = async () => {
  console.log("🔍 Debugging Notification Setup...\n");

  // Check 1: Browser Support
  console.log("1. Browser Support:");
  console.log("  Notification API:", "Notification" in window ? "✅" : "❌");
  console.log("  Service Worker:", "serviceWorker" in navigator ? "✅" : "❌");
  console.log("  Push Manager:", "PushManager" in window ? "✅" : "❌");

  // Check 2: Permission Status
  console.log("\n2. Permission Status:");
  if ("Notification" in window) {
    console.log("  Current permission:", Notification.permission);
    if (Notification.permission === "granted") {
      console.log("  ✅ Notification permission granted");
    } else if (Notification.permission === "denied") {
      console.log("  ❌ Notification permission denied");
    } else {
      console.log("  ⚠️ Notification permission not requested yet");
    }
  }

  // Check 3: Service Worker Status
  console.log("\n3. Service Worker Status:");
  if ("serviceWorker" in navigator) {
    try {
      const registration = await navigator.serviceWorker.getRegistration();
      if (registration) {
        console.log("  ✅ Service Worker registered");
        console.log("  State:", registration.active?.state || "inactive");
        console.log("  Scope:", registration.scope);
      } else {
        console.log("  ❌ Service Worker not registered");
      }
    } catch (error) {
      console.log("  ❌ Service Worker error:", error.message);
    }
  }

  // Check 4: Push Subscription
  console.log("\n4. Push Subscription Status:");
  if ("serviceWorker" in navigator && "PushManager" in window) {
    try {
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.getSubscription();

      if (subscription) {
        console.log("  ✅ Push subscription exists");
        console.log(
          "  Endpoint:",
          subscription.endpoint.substring(0, 50) + "..."
        );
      } else {
        console.log("  ❌ No push subscription found");
      }
    } catch (error) {
      console.log("  ❌ Push subscription error:", error.message);
    }
  }

  // Check 5: Backend Connection
  console.log("\n5. Backend Connection:");
  try {
    const response = await fetch(
      `${API_CONFIG.API_URL}/notifications/vapid-public-key`
    );
    if (response.ok) {
      const data = await response.json();
      if (data.success) {
        console.log("  ✅ Backend notification API accessible");
        console.log(
          "  VAPID Key:",
          data.data.publicKey.substring(0, 20) + "..."
        );
      } else {
        console.log("  ❌ Backend API error:", data.message);
      }
    } else {
      console.log("  ❌ Backend not responding:", response.status);
    }
  } catch (error) {
    console.log("  ❌ Backend connection error:", error.message);
  }

  // Check 6: Authentication Token
  console.log("\n6. Authentication:");
  const token =
    localStorage.getItem("token") ||
    localStorage.getItem("authToken") ||
    sessionStorage.getItem("token") ||
    sessionStorage.getItem("authToken");

  if (token) {
    console.log("  ✅ Auth token found");
    console.log("  Token length:", token.length);
  } else {
    console.log("  ❌ No auth token found");
  }

  // Check 7: Test Notification
  console.log("\n7. Test Local Notification:");
  if (Notification.permission === "granted") {
    try {
      const testNotification = new Notification("Test Notification", {
        body: "This is a test notification from ChatApp",
        icon: "/vite.svg",
        tag: "test",
      });

      setTimeout(() => testNotification.close(), 3000);
      console.log("  ✅ Test notification sent");
    } catch (error) {
      console.log("  ❌ Test notification failed:", error.message);
    }
  } else {
    console.log("  ⚠️ Cannot test - permission not granted");
  }

  console.log("\n🔍 Debug Complete!");
  console.log("\nTo fix issues:");
  console.log("1. Grant notification permission");
  console.log("2. Ensure service worker is registered");
  console.log("3. Check backend is running");
  console.log("4. Verify authentication token");
};

// Auto-debug in development
export const autoDebugNotifications = () => {
  if (import.meta.env.DEV) {
    // Wait for app to load, then debug
    setTimeout(() => {
      console.log("🔍 Auto-debugging notifications in development...");
      debugNotifications();
    }, 3000);
  }
};

// Make it available globally for manual debugging
window.debugNotifications = debugNotifications;
